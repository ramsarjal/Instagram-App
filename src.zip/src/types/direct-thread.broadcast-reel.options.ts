export interface DirectThreadBroadcastReelOptions {
  mediaId: string;
  reelId?: string;
  text?: string;
  mediaType?: 'photo' | 'video';
}
