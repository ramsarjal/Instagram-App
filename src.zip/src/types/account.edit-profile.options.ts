export interface AccountEditProfileOptions {
  external_url: string;
  gender: string;
  phone_number: string;
  username: string;
  first_name: string;
  biography: string;
  email: string;
}
