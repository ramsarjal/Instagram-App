export type SetBestiesInput = {
  add?: Array<string | number>;
  remove?: Array<string | number>;
};
