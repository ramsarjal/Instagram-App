export interface LiveRtmpSettings {
  stream_url: string;
  stream_key: string;
}
