export interface StatusResponse {
  status: string;
}
