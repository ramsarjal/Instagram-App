export interface LiveAddPostLiveToIgtvResponseRootObject {
  success: boolean;
  igtv_post_id: number;
  status: string;
}
