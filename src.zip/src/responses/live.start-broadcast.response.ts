export interface LiveStartBroadcastResponseRootObject {
  media_id: string;
  status: string;
}
