export interface UploadRepositoryVideoResponseRootObject {
  xsharing_nonces: UploadRepositoryVideoResponseXsharing_nonces;
  status: string;
}
export interface UploadRepositoryVideoResponseXsharing_nonces {}
