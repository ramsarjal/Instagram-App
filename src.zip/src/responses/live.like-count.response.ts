export interface LiveLikeCountResponseRootObject {
  likes: number;
  likers: any[];
  like_ts: number;
  burst_likes: number;
  status: string;
}
