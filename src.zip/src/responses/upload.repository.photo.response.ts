export interface UploadRepositoryPhotoResponseRootObject {
  upload_id: string;
  xsharing_nonces: UploadRepositoryPhotoResponseXsharing_nonces;
  status: string;
}
export interface UploadRepositoryPhotoResponseXsharing_nonces {}
