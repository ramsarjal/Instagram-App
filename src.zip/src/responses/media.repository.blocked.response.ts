export interface MediaRepositoryBlockedResponse {
  media_ids: string[];
  status: string;
}
