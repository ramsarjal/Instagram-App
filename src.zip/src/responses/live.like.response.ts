export interface LiveLikeResponseRootObject {
  likes: number;
  burst_likes: number;
  status: string;
}
