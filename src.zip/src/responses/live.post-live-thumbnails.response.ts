export interface LivePostLiveThumbnailsResponseRootObject {
  thumbnails: string[];
  status: string;
}
