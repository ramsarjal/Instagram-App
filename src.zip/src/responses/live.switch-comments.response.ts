export interface LiveSwitchCommentsResponseRootObject {
  comment_muted: number;
  status: string;
}
