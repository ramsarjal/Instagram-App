import { Repository } from './repository';

export abstract class Entity extends Repository {}
