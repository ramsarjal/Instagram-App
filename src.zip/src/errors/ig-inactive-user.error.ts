import { IgResponseError } from './ig-response.error';

export class IgInactiveUserError extends IgResponseError {}
