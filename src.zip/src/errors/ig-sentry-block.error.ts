import { IgResponseError } from './ig-response.error';

export class IgSentryBlockError extends IgResponseError {}
