import { IgResponseError } from './ig-response.error';

export class IgPrivateUserError extends IgResponseError {}
