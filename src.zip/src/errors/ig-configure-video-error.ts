import { IgUploadVideoError } from './ig-upload-video-error';

export class IgConfigureVideoError extends IgUploadVideoError {}
