import { IgResponseError } from './ig-response.error';

export class IgNotFoundError extends IgResponseError {}
