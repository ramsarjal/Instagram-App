import { IgClientError } from './ig-client.error';

export class IgChallengeWrongCodeError extends IgClientError {}
