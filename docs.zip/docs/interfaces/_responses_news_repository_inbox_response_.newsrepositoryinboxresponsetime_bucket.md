> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["responses/news.repository.inbox.response"](../modules/_responses_news_repository_inbox_response_.md) / [NewsRepositoryInboxResponseTime_bucket](_responses_news_repository_inbox_response_.newsrepositoryinboxresponsetime_bucket.md) /

# Interface: NewsRepositoryInboxResponseTime_bucket

## Hierarchy

* **NewsRepositoryInboxResponseTime_bucket**

## Index

### Properties

* [headers](_responses_news_repository_inbox_response_.newsrepositoryinboxresponsetime_bucket.md#headers)
* [indices](_responses_news_repository_inbox_response_.newsrepositoryinboxresponsetime_bucket.md#indices)

## Properties

###  headers

• **headers**: *string[]*

*Defined in [responses/news.repository.inbox.response.ts:114](https://github.com/dilame/instagram-private-api/blob/3e16058/src/responses/news.repository.inbox.response.ts#L114)*

___

###  indices

• **indices**: *number[]*

*Defined in [responses/news.repository.inbox.response.ts:115](https://github.com/dilame/instagram-private-api/blob/3e16058/src/responses/news.repository.inbox.response.ts#L115)*