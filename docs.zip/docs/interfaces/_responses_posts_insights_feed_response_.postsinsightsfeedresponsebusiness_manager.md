> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["responses/posts-insights.feed.response"](../modules/_responses_posts_insights_feed_response_.md) / [PostsInsightsFeedResponseBusiness_manager](_responses_posts_insights_feed_response_.postsinsightsfeedresponsebusiness_manager.md) /

# Interface: PostsInsightsFeedResponseBusiness_manager

## Hierarchy

* **PostsInsightsFeedResponseBusiness_manager**

## Index

### Properties

* [top_posts_unit](_responses_posts_insights_feed_response_.postsinsightsfeedresponsebusiness_manager.md#top_posts_unit)

## Properties

###  top_posts_unit

• **top_posts_unit**: *[PostsInsightsFeedResponseTop_posts_unit](_responses_posts_insights_feed_response_.postsinsightsfeedresponsetop_posts_unit.md)*

*Defined in [responses/posts-insights.feed.response.ts:12](https://github.com/dilame/instagram-private-api/blob/3e16058/src/responses/posts-insights.feed.response.ts#L12)*