> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["responses/posts-insights.feed.response"](../modules/_responses_posts_insights_feed_response_.md) / [PostsInsightsFeedResponseActions](_responses_posts_insights_feed_response_.postsinsightsfeedresponseactions.md) /

# Interface: PostsInsightsFeedResponseActions

## Hierarchy

* **PostsInsightsFeedResponseActions**

## Index

### Properties

* [edges](_responses_posts_insights_feed_response_.postsinsightsfeedresponseactions.md#edges)

## Properties

###  edges

• **edges**: *[PostsInsightsFeedResponseEdgesItem](_responses_posts_insights_feed_response_.postsinsightsfeedresponseedgesitem.md)[]*

*Defined in [responses/posts-insights.feed.response.ts:62](https://github.com/dilame/instagram-private-api/blob/3e16058/src/responses/posts-insights.feed.response.ts#L62)*