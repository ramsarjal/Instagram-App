> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["responses/insights.service.account.response"](../modules/_responses_insights_service_account_response_.md) / [InsightsServiceAccountResponseGender_graph](_responses_insights_service_account_response_.insightsserviceaccountresponsegender_graph.md) /

# Interface: InsightsServiceAccountResponseGender_graph

## Hierarchy

* **InsightsServiceAccountResponseGender_graph**

## Index

### Properties

* [data_points](_responses_insights_service_account_response_.insightsserviceaccountresponsegender_graph.md#data_points)

## Properties

###  data_points

• **data_points**: *[InsightsServiceAccountResponseDataPointsItem](_responses_insights_service_account_response_.insightsserviceaccountresponsedatapointsitem.md)[]*

*Defined in [responses/insights.service.account.response.ts:119](https://github.com/dilame/instagram-private-api/blob/3e16058/src/responses/insights.service.account.response.ts#L119)*