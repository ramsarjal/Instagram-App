> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["responses/media.repository.configure-sidecar.response"](../modules/_responses_media_repository_configure_sidecar_response_.md) / [MediaRepositoryConfigureSidecarResponseUsertags](_responses_media_repository_configure_sidecar_response_.mediarepositoryconfiguresidecarresponseusertags.md) /

# Interface: MediaRepositoryConfigureSidecarResponseUsertags

## Hierarchy

* **MediaRepositoryConfigureSidecarResponseUsertags**

## Index

### Properties

* [in](_responses_media_repository_configure_sidecar_response_.mediarepositoryconfiguresidecarresponseusertags.md#in)

## Properties

###  in

• **in**: *[MediaRepositoryConfigureSidecarResponseInItem](_responses_media_repository_configure_sidecar_response_.mediarepositoryconfiguresidecarresponseinitem.md)[]*

*Defined in [responses/media.repository.configure-sidecar.response.ts:65](https://github.com/dilame/instagram-private-api/blob/3e16058/src/responses/media.repository.configure-sidecar.response.ts#L65)*