> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["responses/music-genre.feed.response"](../modules/_responses_music_genre_feed_response_.md) / [MusicGenreFeedResponseItemsItem](_responses_music_genre_feed_response_.musicgenrefeedresponseitemsitem.md) /

# Interface: MusicGenreFeedResponseItemsItem

## Hierarchy

* **MusicGenreFeedResponseItemsItem**

## Index

### Properties

* [track](_responses_music_genre_feed_response_.musicgenrefeedresponseitemsitem.md#track)

## Properties

###  track

• **track**: *[MusicGenreFeedResponseTrack](_responses_music_genre_feed_response_.musicgenrefeedresponsetrack.md)*

*Defined in [responses/music-genre.feed.response.ts:8](https://github.com/dilame/instagram-private-api/blob/3e16058/src/responses/music-genre.feed.response.ts#L8)*