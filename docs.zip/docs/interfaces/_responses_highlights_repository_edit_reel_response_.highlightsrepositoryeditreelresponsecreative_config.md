> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["responses/highlights.repository.edit-reel.response"](../modules/_responses_highlights_repository_edit_reel_response_.md) / [HighlightsRepositoryEditReelResponseCreative_config](_responses_highlights_repository_edit_reel_response_.highlightsrepositoryeditreelresponsecreative_config.md) /

# Interface: HighlightsRepositoryEditReelResponseCreative_config

## Hierarchy

* **HighlightsRepositoryEditReelResponseCreative_config**

## Index

### Properties

* [camera_facing](_responses_highlights_repository_edit_reel_response_.highlightsrepositoryeditreelresponsecreative_config.md#camera_facing)
* [capture_type](_responses_highlights_repository_edit_reel_response_.highlightsrepositoryeditreelresponsecreative_config.md#capture_type)
* [should_render_try_it_on](_responses_highlights_repository_edit_reel_response_.highlightsrepositoryeditreelresponsecreative_config.md#should_render_try_it_on)

## Properties

###  camera_facing

• **camera_facing**: *string*

*Defined in [responses/highlights.repository.edit-reel.response.ts:121](https://github.com/dilame/instagram-private-api/blob/3e16058/src/responses/highlights.repository.edit-reel.response.ts#L121)*

___

###  capture_type

• **capture_type**: *string*

*Defined in [responses/highlights.repository.edit-reel.response.ts:120](https://github.com/dilame/instagram-private-api/blob/3e16058/src/responses/highlights.repository.edit-reel.response.ts#L120)*

___

###  should_render_try_it_on

• **should_render_try_it_on**: *boolean*

*Defined in [responses/highlights.repository.edit-reel.response.ts:122](https://github.com/dilame/instagram-private-api/blob/3e16058/src/responses/highlights.repository.edit-reel.response.ts#L122)*