> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["responses/insights.service.account.response"](../modules/_responses_insights_service_account_response_.md) / [InsightsServiceAccountResponseGraph](_responses_insights_service_account_response_.insightsserviceaccountresponsegraph.md) /

# Interface: InsightsServiceAccountResponseGraph

## Hierarchy

* **InsightsServiceAccountResponseGraph**

## Index

### Properties

* [nodes](_responses_insights_service_account_response_.insightsserviceaccountresponsegraph.md#nodes)

## Properties

###  nodes

• **nodes**: *[InsightsServiceAccountResponseNodesItem](_responses_insights_service_account_response_.insightsserviceaccountresponsenodesitem.md)[]*

*Defined in [responses/insights.service.account.response.ts:98](https://github.com/dilame/instagram-private-api/blob/3e16058/src/responses/insights.service.account.response.ts#L98)*