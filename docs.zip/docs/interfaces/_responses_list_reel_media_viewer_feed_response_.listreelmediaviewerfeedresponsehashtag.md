> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["responses/list-reel-media-viewer.feed.response"](../modules/_responses_list_reel_media_viewer_feed_response_.md) / [ListReelMediaViewerFeedResponseHashtag](_responses_list_reel_media_viewer_feed_response_.listreelmediaviewerfeedresponsehashtag.md) /

# Interface: ListReelMediaViewerFeedResponseHashtag

## Hierarchy

* **ListReelMediaViewerFeedResponseHashtag**

## Index

### Properties

* [id](_responses_list_reel_media_viewer_feed_response_.listreelmediaviewerfeedresponsehashtag.md#id)
* [name](_responses_list_reel_media_viewer_feed_response_.listreelmediaviewerfeedresponsehashtag.md#name)

## Properties

###  id

• **id**: *string*

*Defined in [responses/list-reel-media-viewer.feed.response.ts:147](https://github.com/dilame/instagram-private-api/blob/3e16058/src/responses/list-reel-media-viewer.feed.response.ts#L147)*

___

###  name

• **name**: *string*

*Defined in [responses/list-reel-media-viewer.feed.response.ts:146](https://github.com/dilame/instagram-private-api/blob/3e16058/src/responses/list-reel-media-viewer.feed.response.ts#L146)*