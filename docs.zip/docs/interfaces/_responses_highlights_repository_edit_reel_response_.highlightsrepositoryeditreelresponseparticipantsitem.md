> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["responses/highlights.repository.edit-reel.response"](../modules/_responses_highlights_repository_edit_reel_response_.md) / [HighlightsRepositoryEditReelResponseParticipantsItem](_responses_highlights_repository_edit_reel_response_.highlightsrepositoryeditreelresponseparticipantsitem.md) /

# Interface: HighlightsRepositoryEditReelResponseParticipantsItem

## Hierarchy

* **HighlightsRepositoryEditReelResponseParticipantsItem**

## Index

### Properties

* [answer](_responses_highlights_repository_edit_reel_response_.highlightsrepositoryeditreelresponseparticipantsitem.md#answer)
* [ts](_responses_highlights_repository_edit_reel_response_.highlightsrepositoryeditreelresponseparticipantsitem.md#ts)
* [user](_responses_highlights_repository_edit_reel_response_.highlightsrepositoryeditreelresponseparticipantsitem.md#user)

## Properties

###  answer

• **answer**: *number*

*Defined in [responses/highlights.repository.edit-reel.response.ts:160](https://github.com/dilame/instagram-private-api/blob/3e16058/src/responses/highlights.repository.edit-reel.response.ts#L160)*

___

###  ts

• **ts**: *number*

*Defined in [responses/highlights.repository.edit-reel.response.ts:161](https://github.com/dilame/instagram-private-api/blob/3e16058/src/responses/highlights.repository.edit-reel.response.ts#L161)*

___

###  user

• **user**: *[HighlightsRepositoryEditReelResponseUser](_responses_highlights_repository_edit_reel_response_.highlightsrepositoryeditreelresponseuser.md)*

*Defined in [responses/highlights.repository.edit-reel.response.ts:159](https://github.com/dilame/instagram-private-api/blob/3e16058/src/responses/highlights.repository.edit-reel.response.ts#L159)*