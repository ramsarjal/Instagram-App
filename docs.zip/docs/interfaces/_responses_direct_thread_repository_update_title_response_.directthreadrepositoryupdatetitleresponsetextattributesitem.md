> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["responses/direct-thread.repository.update-title.response"](../modules/_responses_direct_thread_repository_update_title_response_.md) / [DirectThreadRepositoryUpdateTitleResponseTextAttributesItem](_responses_direct_thread_repository_update_title_response_.directthreadrepositoryupdatetitleresponsetextattributesitem.md) /

# Interface: DirectThreadRepositoryUpdateTitleResponseTextAttributesItem

## Hierarchy

* **DirectThreadRepositoryUpdateTitleResponseTextAttributesItem**

## Index

### Properties

* [bold](_responses_direct_thread_repository_update_title_response_.directthreadrepositoryupdatetitleresponsetextattributesitem.md#bold)
* [color](_responses_direct_thread_repository_update_title_response_.directthreadrepositoryupdatetitleresponsetextattributesitem.md#color)
* [end](_responses_direct_thread_repository_update_title_response_.directthreadrepositoryupdatetitleresponsetextattributesitem.md#end)
* [intent](_responses_direct_thread_repository_update_title_response_.directthreadrepositoryupdatetitleresponsetextattributesitem.md#intent)
* [start](_responses_direct_thread_repository_update_title_response_.directthreadrepositoryupdatetitleresponsetextattributesitem.md#start)

## Properties

###  bold

• **bold**: *number*

*Defined in [responses/direct-thread.repository.update-title.response.ts:95](https://github.com/dilame/instagram-private-api/blob/3e16058/src/responses/direct-thread.repository.update-title.response.ts#L95)*

___

###  color

• **color**: *string*

*Defined in [responses/direct-thread.repository.update-title.response.ts:96](https://github.com/dilame/instagram-private-api/blob/3e16058/src/responses/direct-thread.repository.update-title.response.ts#L96)*

___

###  end

• **end**: *number*

*Defined in [responses/direct-thread.repository.update-title.response.ts:94](https://github.com/dilame/instagram-private-api/blob/3e16058/src/responses/direct-thread.repository.update-title.response.ts#L94)*

___

###  intent

• **intent**: *string*

*Defined in [responses/direct-thread.repository.update-title.response.ts:97](https://github.com/dilame/instagram-private-api/blob/3e16058/src/responses/direct-thread.repository.update-title.response.ts#L97)*

___

###  start

• **start**: *number*

*Defined in [responses/direct-thread.repository.update-title.response.ts:93](https://github.com/dilame/instagram-private-api/blob/3e16058/src/responses/direct-thread.repository.update-title.response.ts#L93)*