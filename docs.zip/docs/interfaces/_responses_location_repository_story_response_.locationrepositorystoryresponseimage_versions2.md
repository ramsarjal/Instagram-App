> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["responses/location.repository.story.response"](../modules/_responses_location_repository_story_response_.md) / [LocationRepositoryStoryResponseImage_versions2](_responses_location_repository_story_response_.locationrepositorystoryresponseimage_versions2.md) /

# Interface: LocationRepositoryStoryResponseImage_versions2

## Hierarchy

* **LocationRepositoryStoryResponseImage_versions2**

## Index

### Properties

* [candidates](_responses_location_repository_story_response_.locationrepositorystoryresponseimage_versions2.md#candidates)

## Properties

###  candidates

• **candidates**: *[LocationRepositoryStoryResponseCandidatesItem](_responses_location_repository_story_response_.locationrepositorystoryresponsecandidatesitem.md)[]*

*Defined in [responses/location.repository.story.response.ts:97](https://github.com/dilame/instagram-private-api/blob/3e16058/src/responses/location.repository.story.response.ts#L97)*