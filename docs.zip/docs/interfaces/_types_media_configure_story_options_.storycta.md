> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["types/media.configure-story.options"](../modules/_types_media_configure_story_options_.md) / [StoryCta](_types_media_configure_story_options_.storycta.md) /

# Interface: StoryCta

## Hierarchy

* **StoryCta**

## Index

### Properties

* [links](_types_media_configure_story_options_.storycta.md#links)

## Properties

###  links

• **links**: *[object]*

*Defined in [types/media.configure-story.options.ts:80](https://github.com/dilame/instagram-private-api/blob/3e16058/src/types/media.configure-story.options.ts#L80)*