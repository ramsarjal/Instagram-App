> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["responses/highlights.repository.create-reel.response"](../modules/_responses_highlights_repository_create_reel_response_.md) / [HighlightsRepositoryCreateReelResponseVideoVersionsItem](_responses_highlights_repository_create_reel_response_.highlightsrepositorycreatereelresponsevideoversionsitem.md) /

# Interface: HighlightsRepositoryCreateReelResponseVideoVersionsItem

## Hierarchy

* **HighlightsRepositoryCreateReelResponseVideoVersionsItem**

## Index

### Properties

* [height](_responses_highlights_repository_create_reel_response_.highlightsrepositorycreatereelresponsevideoversionsitem.md#height)
* [id](_responses_highlights_repository_create_reel_response_.highlightsrepositorycreatereelresponsevideoversionsitem.md#id)
* [type](_responses_highlights_repository_create_reel_response_.highlightsrepositorycreatereelresponsevideoversionsitem.md#type)
* [url](_responses_highlights_repository_create_reel_response_.highlightsrepositorycreatereelresponsevideoversionsitem.md#url)
* [width](_responses_highlights_repository_create_reel_response_.highlightsrepositorycreatereelresponsevideoversionsitem.md#width)

## Properties

###  height

• **height**: *number*

*Defined in [responses/highlights.repository.create-reel.response.ts:115](https://github.com/dilame/instagram-private-api/blob/3e16058/src/responses/highlights.repository.create-reel.response.ts#L115)*

___

###  id

• **id**: *string*

*Defined in [responses/highlights.repository.create-reel.response.ts:117](https://github.com/dilame/instagram-private-api/blob/3e16058/src/responses/highlights.repository.create-reel.response.ts#L117)*

___

###  type

• **type**: *number*

*Defined in [responses/highlights.repository.create-reel.response.ts:113](https://github.com/dilame/instagram-private-api/blob/3e16058/src/responses/highlights.repository.create-reel.response.ts#L113)*

___

###  url

• **url**: *string*

*Defined in [responses/highlights.repository.create-reel.response.ts:116](https://github.com/dilame/instagram-private-api/blob/3e16058/src/responses/highlights.repository.create-reel.response.ts#L116)*

___

###  width

• **width**: *number*

*Defined in [responses/highlights.repository.create-reel.response.ts:114](https://github.com/dilame/instagram-private-api/blob/3e16058/src/responses/highlights.repository.create-reel.response.ts#L114)*