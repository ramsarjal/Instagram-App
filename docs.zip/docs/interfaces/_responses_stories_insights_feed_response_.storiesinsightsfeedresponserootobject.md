> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["responses/stories-insights.feed.response"](../modules/_responses_stories_insights_feed_response_.md) / [StoriesInsightsFeedResponseRootObject](_responses_stories_insights_feed_response_.storiesinsightsfeedresponserootobject.md) /

# Interface: StoriesInsightsFeedResponseRootObject

## Hierarchy

* **StoriesInsightsFeedResponseRootObject**

## Index

### Properties

* [data](_responses_stories_insights_feed_response_.storiesinsightsfeedresponserootobject.md#data)

## Properties

###  data

• **data**: *[StoriesInsightsFeedResponseData](_responses_stories_insights_feed_response_.storiesinsightsfeedresponsedata.md)*

*Defined in [responses/stories-insights.feed.response.ts:2](https://github.com/dilame/instagram-private-api/blob/3e16058/src/responses/stories-insights.feed.response.ts#L2)*