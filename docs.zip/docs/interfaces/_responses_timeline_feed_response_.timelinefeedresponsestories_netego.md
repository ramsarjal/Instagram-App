> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["responses/timeline.feed.response"](../modules/_responses_timeline_feed_response_.md) / [TimelineFeedResponseStories_netego](_responses_timeline_feed_response_.timelinefeedresponsestories_netego.md) /

# Interface: TimelineFeedResponseStories_netego

## Hierarchy

* **TimelineFeedResponseStories_netego**

## Index

### Properties

* [hide_unit_if_seen](_responses_timeline_feed_response_.timelinefeedresponsestories_netego.md#hide_unit_if_seen)
* [id](_responses_timeline_feed_response_.timelinefeedresponsestories_netego.md#id)
* [tracking_token](_responses_timeline_feed_response_.timelinefeedresponsestories_netego.md#tracking_token)

## Properties

###  hide_unit_if_seen

• **hide_unit_if_seen**: *string*

*Defined in [responses/timeline.feed.response.ts:279](https://github.com/dilame/instagram-private-api/blob/3e16058/src/responses/timeline.feed.response.ts#L279)*

___

###  id

• **id**: *number*

*Defined in [responses/timeline.feed.response.ts:280](https://github.com/dilame/instagram-private-api/blob/3e16058/src/responses/timeline.feed.response.ts#L280)*

___

###  tracking_token

• **tracking_token**: *string*

*Defined in [responses/timeline.feed.response.ts:278](https://github.com/dilame/instagram-private-api/blob/3e16058/src/responses/timeline.feed.response.ts#L278)*