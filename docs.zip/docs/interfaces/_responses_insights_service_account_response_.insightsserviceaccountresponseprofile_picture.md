> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["responses/insights.service.account.response"](../modules/_responses_insights_service_account_response_.md) / [InsightsServiceAccountResponseProfile_picture](_responses_insights_service_account_response_.insightsserviceaccountresponseprofile_picture.md) /

# Interface: InsightsServiceAccountResponseProfile_picture

## Hierarchy

* **InsightsServiceAccountResponseProfile_picture**

## Index

### Properties

* [uri](_responses_insights_service_account_response_.insightsserviceaccountresponseprofile_picture.md#uri)

## Properties

###  uri

• **uri**: *string*

*Defined in [responses/insights.service.account.response.ts:171](https://github.com/dilame/instagram-private-api/blob/3e16058/src/responses/insights.service.account.response.ts#L171)*