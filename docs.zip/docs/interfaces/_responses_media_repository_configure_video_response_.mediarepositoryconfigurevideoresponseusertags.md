> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["responses/media.repository.configure-video.response"](../modules/_responses_media_repository_configure_video_response_.md) / [MediaRepositoryConfigureVideoResponseUsertags](_responses_media_repository_configure_video_response_.mediarepositoryconfigurevideoresponseusertags.md) /

# Interface: MediaRepositoryConfigureVideoResponseUsertags

## Hierarchy

* **MediaRepositoryConfigureVideoResponseUsertags**

## Index

### Properties

* [in](_responses_media_repository_configure_video_response_.mediarepositoryconfigurevideoresponseusertags.md#in)

## Properties

###  in

• **in**: *[MediaRepositoryConfigureVideoResponseInItem](_responses_media_repository_configure_video_response_.mediarepositoryconfigurevideoresponseinitem.md)[]*

*Defined in [responses/media.repository.configure-video.response.ts:62](https://github.com/dilame/instagram-private-api/blob/3e16058/src/responses/media.repository.configure-video.response.ts#L62)*