> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["responses/timeline.feed.response"](../modules/_responses_timeline_feed_response_.md) / [TimelineFeedResponseClientGapEnforcerMatrixItem](_responses_timeline_feed_response_.timelinefeedresponseclientgapenforcermatrixitem.md) /

# Interface: TimelineFeedResponseClientGapEnforcerMatrixItem

## Hierarchy

* **TimelineFeedResponseClientGapEnforcerMatrixItem**

## Index

### Properties

* [list](_responses_timeline_feed_response_.timelinefeedresponseclientgapenforcermatrixitem.md#list)

## Properties

###  list

• **list**: *number[]*

*Defined in [responses/timeline.feed.response.ts:287](https://github.com/dilame/instagram-private-api/blob/3e16058/src/responses/timeline.feed.response.ts#L287)*