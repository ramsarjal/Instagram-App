> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["responses/highlights.repository.create-reel.response"](../modules/_responses_highlights_repository_create_reel_response_.md) / [HighlightsRepositoryCreateReelResponseCropped_image_version](_responses_highlights_repository_create_reel_response_.highlightsrepositorycreatereelresponsecropped_image_version.md) /

# Interface: HighlightsRepositoryCreateReelResponseCropped_image_version

## Hierarchy

* **HighlightsRepositoryCreateReelResponseCropped_image_version**

## Index

### Properties

* [estimated_scans_sizes](_responses_highlights_repository_create_reel_response_.highlightsrepositorycreatereelresponsecropped_image_version.md#estimated_scans_sizes)
* [height](_responses_highlights_repository_create_reel_response_.highlightsrepositorycreatereelresponsecropped_image_version.md#height)
* [url](_responses_highlights_repository_create_reel_response_.highlightsrepositorycreatereelresponsecropped_image_version.md#url)
* [width](_responses_highlights_repository_create_reel_response_.highlightsrepositorycreatereelresponsecropped_image_version.md#width)

## Properties

###  estimated_scans_sizes

• **estimated_scans_sizes**: *number[]*

*Defined in [responses/highlights.repository.create-reel.response.ts:34](https://github.com/dilame/instagram-private-api/blob/3e16058/src/responses/highlights.repository.create-reel.response.ts#L34)*

___

###  height

• **height**: *number*

*Defined in [responses/highlights.repository.create-reel.response.ts:32](https://github.com/dilame/instagram-private-api/blob/3e16058/src/responses/highlights.repository.create-reel.response.ts#L32)*

___

###  url

• **url**: *string*

*Defined in [responses/highlights.repository.create-reel.response.ts:33](https://github.com/dilame/instagram-private-api/blob/3e16058/src/responses/highlights.repository.create-reel.response.ts#L33)*

___

###  width

• **width**: *number*

*Defined in [responses/highlights.repository.create-reel.response.ts:31](https://github.com/dilame/instagram-private-api/blob/3e16058/src/responses/highlights.repository.create-reel.response.ts#L31)*