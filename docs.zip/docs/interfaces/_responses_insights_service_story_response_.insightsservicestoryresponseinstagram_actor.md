> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["responses/insights.service.story.response"](../modules/_responses_insights_service_story_response_.md) / [InsightsServiceStoryResponseInstagram_actor](_responses_insights_service_story_response_.insightsservicestoryresponseinstagram_actor.md) /

# Interface: InsightsServiceStoryResponseInstagram_actor

## Hierarchy

* **InsightsServiceStoryResponseInstagram_actor**

## Index

### Properties

* [id](_responses_insights_service_story_response_.insightsservicestoryresponseinstagram_actor.md#id)
* [instagram_actor_id](_responses_insights_service_story_response_.insightsservicestoryresponseinstagram_actor.md#instagram_actor_id)

## Properties

###  id

• **id**: *string*

*Defined in [responses/insights.service.story.response.ts:24](https://github.com/dilame/instagram-private-api/blob/3e16058/src/responses/insights.service.story.response.ts#L24)*

___

###  instagram_actor_id

• **instagram_actor_id**: *string*

*Defined in [responses/insights.service.story.response.ts:23](https://github.com/dilame/instagram-private-api/blob/3e16058/src/responses/insights.service.story.response.ts#L23)*