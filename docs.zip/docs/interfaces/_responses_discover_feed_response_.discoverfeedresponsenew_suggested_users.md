> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["responses/discover.feed.response"](../modules/_responses_discover_feed_response_.md) / [DiscoverFeedResponseNew_suggested_users](_responses_discover_feed_response_.discoverfeedresponsenew_suggested_users.md) /

# Interface: DiscoverFeedResponseNew_suggested_users

## Hierarchy

* **DiscoverFeedResponseNew_suggested_users**

## Index

### Properties

* [suggestions](_responses_discover_feed_response_.discoverfeedresponsenew_suggested_users.md#suggestions)

## Properties

###  suggestions

• **suggestions**: *any[]*

*Defined in [responses/discover.feed.response.ts:40](https://github.com/dilame/instagram-private-api/blob/3e16058/src/responses/discover.feed.response.ts#L40)*