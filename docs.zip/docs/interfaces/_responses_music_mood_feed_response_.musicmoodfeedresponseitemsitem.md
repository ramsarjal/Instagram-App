> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["responses/music-mood.feed.response"](../modules/_responses_music_mood_feed_response_.md) / [MusicMoodFeedResponseItemsItem](_responses_music_mood_feed_response_.musicmoodfeedresponseitemsitem.md) /

# Interface: MusicMoodFeedResponseItemsItem

## Hierarchy

* **MusicMoodFeedResponseItemsItem**

## Index

### Properties

* [track](_responses_music_mood_feed_response_.musicmoodfeedresponseitemsitem.md#track)

## Properties

###  track

• **track**: *[MusicMoodFeedResponseTrack](_responses_music_mood_feed_response_.musicmoodfeedresponsetrack.md)*

*Defined in [responses/music-mood.feed.response.ts:8](https://github.com/dilame/instagram-private-api/blob/3e16058/src/responses/music-mood.feed.response.ts#L8)*