> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["responses/restrict-action.repository.restrict.response"](../modules/_responses_restrict_action_repository_restrict_response_.md) / [RestrictActionRepositoryRestrictResponseRootObject](_responses_restrict_action_repository_restrict_response_.restrictactionrepositoryrestrictresponserootobject.md) /

# Interface: RestrictActionRepositoryRestrictResponseRootObject

## Hierarchy

* **RestrictActionRepositoryRestrictResponseRootObject**

## Index

### Properties

* [status](_responses_restrict_action_repository_restrict_response_.restrictactionrepositoryrestrictresponserootobject.md#status)
* [users](_responses_restrict_action_repository_restrict_response_.restrictactionrepositoryrestrictresponserootobject.md#users)

## Properties

###  status

• **status**: *string*

*Defined in [responses/restrict-action.repository.restrict.response.ts:3](https://github.com/dilame/instagram-private-api/blob/3e16058/src/responses/restrict-action.repository.restrict.response.ts#L3)*

___

###  users

• **users**: *[RestrictActionRepositoryRestrictResponseUsersItem](_responses_restrict_action_repository_restrict_response_.restrictactionrepositoryrestrictresponseusersitem.md)[]*

*Defined in [responses/restrict-action.repository.restrict.response.ts:2](https://github.com/dilame/instagram-private-api/blob/3e16058/src/responses/restrict-action.repository.restrict.response.ts#L2)*