> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["responses/insights.service.account.response"](../modules/_responses_insights_service_account_response_.md) / [InsightsServiceAccountResponseSummary_stories](_responses_insights_service_account_response_.insightsserviceaccountresponsesummary_stories.md) /

# Interface: InsightsServiceAccountResponseSummary_stories

## Hierarchy

* **InsightsServiceAccountResponseSummary_stories**

## Index

### Properties

* [count](_responses_insights_service_account_response_.insightsserviceaccountresponsesummary_stories.md#count)
* [edges](_responses_insights_service_account_response_.insightsserviceaccountresponsesummary_stories.md#edges)

## Properties

###  count

• **count**: *number*

*Defined in [responses/insights.service.account.response.ts:158](https://github.com/dilame/instagram-private-api/blob/3e16058/src/responses/insights.service.account.response.ts#L158)*

___

###  edges

• **edges**: *any[]*

*Defined in [responses/insights.service.account.response.ts:159](https://github.com/dilame/instagram-private-api/blob/3e16058/src/responses/insights.service.account.response.ts#L159)*