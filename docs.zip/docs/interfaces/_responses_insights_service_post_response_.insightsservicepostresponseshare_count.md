> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["responses/insights.service.post.response"](../modules/_responses_insights_service_post_response_.md) / [InsightsServicePostResponseShare_count](_responses_insights_service_post_response_.insightsservicepostresponseshare_count.md) /

# Interface: InsightsServicePostResponseShare_count

## Hierarchy

* **InsightsServicePostResponseShare_count**

## Index

### Properties

* [post](_responses_insights_service_post_response_.insightsservicepostresponseshare_count.md#post)
* [tray](_responses_insights_service_post_response_.insightsservicepostresponseshare_count.md#tray)

## Properties

###  post

• **post**: *[InsightsServicePostResponsePost](_responses_insights_service_post_response_.insightsservicepostresponsepost.md)*

*Defined in [responses/insights.service.post.response.ts:48](https://github.com/dilame/instagram-private-api/blob/3e16058/src/responses/insights.service.post.response.ts#L48)*

___

###  tray

• **tray**: *[InsightsServicePostResponseTray](_responses_insights_service_post_response_.insightsservicepostresponsetray.md)*

*Defined in [responses/insights.service.post.response.ts:47](https://github.com/dilame/instagram-private-api/blob/3e16058/src/responses/insights.service.post.response.ts#L47)*