> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["responses/user.feed.response"](../modules/_responses_user_feed_response_.md) / [UserFeedResponseFb_user_tags](_responses_user_feed_response_.userfeedresponsefb_user_tags.md) /

# Interface: UserFeedResponseFb_user_tags

## Hierarchy

* **UserFeedResponseFb_user_tags**

## Index

### Properties

* [in](_responses_user_feed_response_.userfeedresponsefb_user_tags.md#in)

## Properties

###  in

• **in**: *any[]*

*Defined in [responses/user.feed.response.ts:90](https://github.com/dilame/instagram-private-api/blob/3e16058/src/responses/user.feed.response.ts#L90)*