> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["responses/posts-insights.feed.response"](../modules/_responses_posts_insights_feed_response_.md) / [PostsInsightsFeedResponseTop_posts_unit](_responses_posts_insights_feed_response_.postsinsightsfeedresponsetop_posts_unit.md) /

# Interface: PostsInsightsFeedResponseTop_posts_unit

## Hierarchy

* **PostsInsightsFeedResponseTop_posts_unit**

## Index

### Properties

* [top_posts](_responses_posts_insights_feed_response_.postsinsightsfeedresponsetop_posts_unit.md#top_posts)

## Properties

###  top_posts

• **top_posts**: *[PostsInsightsFeedResponseTop_posts](_responses_posts_insights_feed_response_.postsinsightsfeedresponsetop_posts.md)*

*Defined in [responses/posts-insights.feed.response.ts:15](https://github.com/dilame/instagram-private-api/blob/3e16058/src/responses/posts-insights.feed.response.ts#L15)*