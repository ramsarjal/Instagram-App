> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["responses/insights.service.post.response"](../modules/_responses_insights_service_post_response_.md) / [InsightsServicePostResponseActions](_responses_insights_service_post_response_.insightsservicepostresponseactions.md) /

# Interface: InsightsServicePostResponseActions

## Hierarchy

* **InsightsServicePostResponseActions**

## Index

### Properties

* [nodes](_responses_insights_service_post_response_.insightsservicepostresponseactions.md#nodes)
* [value](_responses_insights_service_post_response_.insightsservicepostresponseactions.md#value)

## Properties

###  nodes

• **nodes**: *[InsightsServicePostResponseNodesItem](_responses_insights_service_post_response_.insightsservicepostresponsenodesitem.md)[]*

*Defined in [responses/insights.service.post.response.ts:67](https://github.com/dilame/instagram-private-api/blob/3e16058/src/responses/insights.service.post.response.ts#L67)*

___

###  value

• **value**: *number*

*Defined in [responses/insights.service.post.response.ts:66](https://github.com/dilame/instagram-private-api/blob/3e16058/src/responses/insights.service.post.response.ts#L66)*