> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["responses/posts-insights.feed.response"](../modules/_responses_posts_insights_feed_response_.md) / [PostsInsightsFeedResponseRootObject](_responses_posts_insights_feed_response_.postsinsightsfeedresponserootobject.md) /

# Interface: PostsInsightsFeedResponseRootObject

## Hierarchy

* **PostsInsightsFeedResponseRootObject**

## Index

### Properties

* [data](_responses_posts_insights_feed_response_.postsinsightsfeedresponserootobject.md#data)

## Properties

###  data

• **data**: *[PostsInsightsFeedResponseData](_responses_posts_insights_feed_response_.postsinsightsfeedresponsedata.md)*

*Defined in [responses/posts-insights.feed.response.ts:2](https://github.com/dilame/instagram-private-api/blob/3e16058/src/responses/posts-insights.feed.response.ts#L2)*