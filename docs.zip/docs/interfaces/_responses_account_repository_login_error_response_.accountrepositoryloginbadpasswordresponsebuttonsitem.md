> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["responses/account.repository.login.error.response"](../modules/_responses_account_repository_login_error_response_.md) / [AccountRepositoryLoginBadPasswordResponseButtonsItem](_responses_account_repository_login_error_response_.accountrepositoryloginbadpasswordresponsebuttonsitem.md) /

# Interface: AccountRepositoryLoginBadPasswordResponseButtonsItem

## Hierarchy

* **AccountRepositoryLoginBadPasswordResponseButtonsItem**

## Index

### Properties

* [action](_responses_account_repository_login_error_response_.accountrepositoryloginbadpasswordresponsebuttonsitem.md#action)
* [title](_responses_account_repository_login_error_response_.accountrepositoryloginbadpasswordresponsebuttonsitem.md#title)

## Properties

###  action

• **action**: *string*

*Defined in [responses/account.repository.login.error.response.ts:32](https://github.com/dilame/instagram-private-api/blob/3e16058/src/responses/account.repository.login.error.response.ts#L32)*

___

###  title

• **title**: *string*

*Defined in [responses/account.repository.login.error.response.ts:31](https://github.com/dilame/instagram-private-api/blob/3e16058/src/responses/account.repository.login.error.response.ts#L31)*