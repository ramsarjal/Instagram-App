> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["responses/insights.service.post.response"](../modules/_responses_insights_service_post_response_.md) / [InsightsServicePostResponseHashtags](_responses_insights_service_post_response_.insightsservicepostresponsehashtags.md) /

# Interface: InsightsServicePostResponseHashtags

## Hierarchy

* **InsightsServicePostResponseHashtags**

## Index

### Properties

* [count](_responses_insights_service_post_response_.insightsservicepostresponsehashtags.md#count)
* [nodes](_responses_insights_service_post_response_.insightsservicepostresponsehashtags.md#nodes)

## Properties

###  count

• **count**: *number*

*Defined in [responses/insights.service.post.response.ts:92](https://github.com/dilame/instagram-private-api/blob/3e16058/src/responses/insights.service.post.response.ts#L92)*

___

###  nodes

• **nodes**: *any[]*

*Defined in [responses/insights.service.post.response.ts:93](https://github.com/dilame/instagram-private-api/blob/3e16058/src/responses/insights.service.post.response.ts#L93)*