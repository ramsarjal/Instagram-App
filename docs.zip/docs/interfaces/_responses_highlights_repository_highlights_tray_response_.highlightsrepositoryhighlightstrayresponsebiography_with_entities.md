> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["responses/highlights.repository.highlights-tray.response"](../modules/_responses_highlights_repository_highlights_tray_response_.md) / [HighlightsRepositoryHighlightsTrayResponseBiography_with_entities](_responses_highlights_repository_highlights_tray_response_.highlightsrepositoryhighlightstrayresponsebiography_with_entities.md) /

# Interface: HighlightsRepositoryHighlightsTrayResponseBiography_with_entities

## Hierarchy

* **HighlightsRepositoryHighlightsTrayResponseBiography_with_entities**

## Index

### Properties

* [entities](_responses_highlights_repository_highlights_tray_response_.highlightsrepositoryhighlightstrayresponsebiography_with_entities.md#entities)
* [raw_text](_responses_highlights_repository_highlights_tray_response_.highlightsrepositoryhighlightstrayresponsebiography_with_entities.md#raw_text)

## Properties

###  entities

• **entities**: *any[]*

*Defined in [responses/highlights.repository.highlights-tray.response.ts:199](https://github.com/dilame/instagram-private-api/blob/3e16058/src/responses/highlights.repository.highlights-tray.response.ts#L199)*

___

###  raw_text

• **raw_text**: *string*

*Defined in [responses/highlights.repository.highlights-tray.response.ts:198](https://github.com/dilame/instagram-private-api/blob/3e16058/src/responses/highlights.repository.highlights-tray.response.ts#L198)*