> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["responses/saved.feed.response"](../modules/_responses_saved_feed_response_.md) / [SavedFeedResponseProduct_tags](_responses_saved_feed_response_.savedfeedresponseproduct_tags.md) /

# Interface: SavedFeedResponseProduct_tags

## Hierarchy

* **SavedFeedResponseProduct_tags**

## Index

### Properties

* [in](_responses_saved_feed_response_.savedfeedresponseproduct_tags.md#in)

## Properties

###  in

• **in**: *[SavedFeedResponseInItem](_responses_saved_feed_response_.savedfeedresponseinitem.md)[]*

*Defined in [responses/saved.feed.response.ts:112](https://github.com/dilame/instagram-private-api/blob/3e16058/src/responses/saved.feed.response.ts#L112)*