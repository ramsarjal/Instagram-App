> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["responses/news.repository.inbox.response"](../modules/_responses_news_repository_inbox_response_.md) / [NewsRepositoryInboxResponseBusiness_profile_reminder](_responses_news_repository_inbox_response_.newsrepositoryinboxresponsebusiness_profile_reminder.md) /

# Interface: NewsRepositoryInboxResponseBusiness_profile_reminder

## Hierarchy

* **NewsRepositoryInboxResponseBusiness_profile_reminder**

## Index

### Properties

* [subtitle](_responses_news_repository_inbox_response_.newsrepositoryinboxresponsebusiness_profile_reminder.md#subtitle)
* [title](_responses_news_repository_inbox_response_.newsrepositoryinboxresponsebusiness_profile_reminder.md#title)

## Properties

###  subtitle

• **subtitle**: *string*

*Defined in [responses/news.repository.inbox.response.ts:122](https://github.com/dilame/instagram-private-api/blob/3e16058/src/responses/news.repository.inbox.response.ts#L122)*

___

###  title

• **title**: *string*

*Defined in [responses/news.repository.inbox.response.ts:121](https://github.com/dilame/instagram-private-api/blob/3e16058/src/responses/news.repository.inbox.response.ts#L121)*