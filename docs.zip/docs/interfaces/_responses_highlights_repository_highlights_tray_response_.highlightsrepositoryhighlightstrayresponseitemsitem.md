> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["responses/highlights.repository.highlights-tray.response"](../modules/_responses_highlights_repository_highlights_tray_response_.md) / [HighlightsRepositoryHighlightsTrayResponseItemsItem](_responses_highlights_repository_highlights_tray_response_.highlightsrepositoryhighlightstrayresponseitemsitem.md) /

# Interface: HighlightsRepositoryHighlightsTrayResponseItemsItem

## Hierarchy

* **HighlightsRepositoryHighlightsTrayResponseItemsItem**

## Index

### Properties

* [can_view_more_preview_comments](_responses_highlights_repository_highlights_tray_response_.highlightsrepositoryhighlightstrayresponseitemsitem.md#can_view_more_preview_comments)
* [can_viewer_reshare](_responses_highlights_repository_highlights_tray_response_.highlightsrepositoryhighlightstrayresponseitemsitem.md#can_viewer_reshare)
* [can_viewer_save](_responses_highlights_repository_highlights_tray_response_.highlightsrepositoryhighlightstrayresponseitemsitem.md#can_viewer_save)
* [caption](_responses_highlights_repository_highlights_tray_response_.highlightsrepositoryhighlightstrayresponseitemsitem.md#caption)
* [caption_is_edited](_responses_highlights_repository_highlights_tray_response_.highlightsrepositoryhighlightstrayresponseitemsitem.md#caption_is_edited)
* [client_cache_key](_responses_highlights_repository_highlights_tray_response_.highlightsrepositoryhighlightstrayresponseitemsitem.md#client_cache_key)
* [code](_responses_highlights_repository_highlights_tray_response_.highlightsrepositoryhighlightstrayresponseitemsitem.md#code)
* [comment_count](_responses_highlights_repository_highlights_tray_response_.highlightsrepositoryhighlightstrayresponseitemsitem.md#comment_count)
* [comment_likes_enabled](_responses_highlights_repository_highlights_tray_response_.highlightsrepositoryhighlightstrayresponseitemsitem.md#comment_likes_enabled)
* [comment_threading_enabled](_responses_highlights_repository_highlights_tray_response_.highlightsrepositoryhighlightstrayresponseitemsitem.md#comment_threading_enabled)
* [device_timestamp](_responses_highlights_repository_highlights_tray_response_.highlightsrepositoryhighlightstrayresponseitemsitem.md#device_timestamp)
* [filter_type](_responses_highlights_repository_highlights_tray_response_.highlightsrepositoryhighlightstrayresponseitemsitem.md#filter_type)
* [has_audio](_responses_highlights_repository_highlights_tray_response_.highlightsrepositoryhighlightstrayresponseitemsitem.md#has_audio)
* [has_liked](_responses_highlights_repository_highlights_tray_response_.highlightsrepositoryhighlightstrayresponseitemsitem.md#has_liked)
* [has_more_comments](_responses_highlights_repository_highlights_tray_response_.highlightsrepositoryhighlightstrayresponseitemsitem.md#has_more_comments)
* [id](_responses_highlights_repository_highlights_tray_response_.highlightsrepositoryhighlightstrayresponseitemsitem.md#id)
* [image_versions2](_responses_highlights_repository_highlights_tray_response_.highlightsrepositoryhighlightstrayresponseitemsitem.md#image_versions2)
* [is_dash_eligible](_responses_highlights_repository_highlights_tray_response_.highlightsrepositoryhighlightstrayresponseitemsitem.md#is_dash_eligible)
* [like_count](_responses_highlights_repository_highlights_tray_response_.highlightsrepositoryhighlightstrayresponseitemsitem.md#like_count)
* [max_num_visible_preview_comments](_responses_highlights_repository_highlights_tray_response_.highlightsrepositoryhighlightstrayresponseitemsitem.md#max_num_visible_preview_comments)
* [media_cropping_info](_responses_highlights_repository_highlights_tray_response_.highlightsrepositoryhighlightstrayresponseitemsitem.md#media_cropping_info)
* [media_type](_responses_highlights_repository_highlights_tray_response_.highlightsrepositoryhighlightstrayresponseitemsitem.md#media_type)
* [nearly_complete_copyright_match](_responses_highlights_repository_highlights_tray_response_.highlightsrepositoryhighlightstrayresponseitemsitem.md#nearly_complete_copyright_match)
* [next_max_id](_responses_highlights_repository_highlights_tray_response_.highlightsrepositoryhighlightstrayresponseitemsitem.md#next_max_id)
* [number_of_qualities](_responses_highlights_repository_highlights_tray_response_.highlightsrepositoryhighlightstrayresponseitemsitem.md#number_of_qualities)
* [organic_tracking_token](_responses_highlights_repository_highlights_tray_response_.highlightsrepositoryhighlightstrayresponseitemsitem.md#organic_tracking_token)
* [original_height](_responses_highlights_repository_highlights_tray_response_.highlightsrepositoryhighlightstrayresponseitemsitem.md#original_height)
* [original_width](_responses_highlights_repository_highlights_tray_response_.highlightsrepositoryhighlightstrayresponseitemsitem.md#original_width)
* [photo_of_you](_responses_highlights_repository_highlights_tray_response_.highlightsrepositoryhighlightstrayresponseitemsitem.md#photo_of_you)
* [pk](_responses_highlights_repository_highlights_tray_response_.highlightsrepositoryhighlightstrayresponseitemsitem.md#pk)
* [preview_comments](_responses_highlights_repository_highlights_tray_response_.highlightsrepositoryhighlightstrayresponseitemsitem.md#preview_comments)
* [product_type](_responses_highlights_repository_highlights_tray_response_.highlightsrepositoryhighlightstrayresponseitemsitem.md#product_type)
* [taken_at](_responses_highlights_repository_highlights_tray_response_.highlightsrepositoryhighlightstrayresponseitemsitem.md#taken_at)
* [thumbnails](_responses_highlights_repository_highlights_tray_response_.highlightsrepositoryhighlightstrayresponseitemsitem.md#thumbnails)
* [title](_responses_highlights_repository_highlights_tray_response_.highlightsrepositoryhighlightstrayresponseitemsitem.md#title)
* [user](_responses_highlights_repository_highlights_tray_response_.highlightsrepositoryhighlightstrayresponseitemsitem.md#user)
* [video_codec](_responses_highlights_repository_highlights_tray_response_.highlightsrepositoryhighlightstrayresponseitemsitem.md#video_codec)
* [video_dash_manifest](_responses_highlights_repository_highlights_tray_response_.highlightsrepositoryhighlightstrayresponseitemsitem.md#video_dash_manifest)
* [video_duration](_responses_highlights_repository_highlights_tray_response_.highlightsrepositoryhighlightstrayresponseitemsitem.md#video_duration)
* [video_versions](_responses_highlights_repository_highlights_tray_response_.highlightsrepositoryhighlightstrayresponseitemsitem.md#video_versions)
* [view_count](_responses_highlights_repository_highlights_tray_response_.highlightsrepositoryhighlightstrayresponseitemsitem.md#view_count)

## Properties

###  can_view_more_preview_comments

• **can_view_more_preview_comments**: *boolean*

*Defined in [responses/highlights.repository.highlights-tray.response.ts:87](https://github.com/dilame/instagram-private-api/blob/3e16058/src/responses/highlights.repository.highlights-tray.response.ts#L87)*

___

###  can_viewer_reshare

• **can_viewer_reshare**: *boolean*

*Defined in [responses/highlights.repository.highlights-tray.response.ts:79](https://github.com/dilame/instagram-private-api/blob/3e16058/src/responses/highlights.repository.highlights-tray.response.ts#L79)*

___

###  can_viewer_save

• **can_viewer_save**: *boolean*

*Defined in [responses/highlights.repository.highlights-tray.response.ts:98](https://github.com/dilame/instagram-private-api/blob/3e16058/src/responses/highlights.repository.highlights-tray.response.ts#L98)*

___

###  caption

• **caption**: *[HighlightsRepositoryHighlightsTrayResponseCaption](_responses_highlights_repository_highlights_tray_response_.highlightsrepositoryhighlightstrayresponsecaption.md)*

*Defined in [responses/highlights.repository.highlights-tray.response.ts:97](https://github.com/dilame/instagram-private-api/blob/3e16058/src/responses/highlights.repository.highlights-tray.response.ts#L97)*

___

###  caption_is_edited

• **caption_is_edited**: *boolean*

*Defined in [responses/highlights.repository.highlights-tray.response.ts:80](https://github.com/dilame/instagram-private-api/blob/3e16058/src/responses/highlights.repository.highlights-tray.response.ts#L80)*

___

###  client_cache_key

• **client_cache_key**: *string*

*Defined in [responses/highlights.repository.highlights-tray.response.ts:65](https://github.com/dilame/instagram-private-api/blob/3e16058/src/responses/highlights.repository.highlights-tray.response.ts#L65)*

___

###  code

• **code**: *string*

*Defined in [responses/highlights.repository.highlights-tray.response.ts:64](https://github.com/dilame/instagram-private-api/blob/3e16058/src/responses/highlights.repository.highlights-tray.response.ts#L64)*

___

###  comment_count

• **comment_count**: *number*

*Defined in [responses/highlights.repository.highlights-tray.response.ts:88](https://github.com/dilame/instagram-private-api/blob/3e16058/src/responses/highlights.repository.highlights-tray.response.ts#L88)*

___

###  comment_likes_enabled

• **comment_likes_enabled**: *boolean*

*Defined in [responses/highlights.repository.highlights-tray.response.ts:81](https://github.com/dilame/instagram-private-api/blob/3e16058/src/responses/highlights.repository.highlights-tray.response.ts#L81)*

___

###  comment_threading_enabled

• **comment_threading_enabled**: *boolean*

*Defined in [responses/highlights.repository.highlights-tray.response.ts:82](https://github.com/dilame/instagram-private-api/blob/3e16058/src/responses/highlights.repository.highlights-tray.response.ts#L82)*

___

###  device_timestamp

• **device_timestamp**: *number*

*Defined in [responses/highlights.repository.highlights-tray.response.ts:62](https://github.com/dilame/instagram-private-api/blob/3e16058/src/responses/highlights.repository.highlights-tray.response.ts#L62)*

___

###  filter_type

• **filter_type**: *number*

*Defined in [responses/highlights.repository.highlights-tray.response.ts:66](https://github.com/dilame/instagram-private-api/blob/3e16058/src/responses/highlights.repository.highlights-tray.response.ts#L66)*

___

###  has_audio

• **has_audio**: *boolean*

*Defined in [responses/highlights.repository.highlights-tray.response.ts:75](https://github.com/dilame/instagram-private-api/blob/3e16058/src/responses/highlights.repository.highlights-tray.response.ts#L75)*

___

###  has_liked

• **has_liked**: *boolean*

*Defined in [responses/highlights.repository.highlights-tray.response.ts:95](https://github.com/dilame/instagram-private-api/blob/3e16058/src/responses/highlights.repository.highlights-tray.response.ts#L95)*

___

###  has_more_comments

• **has_more_comments**: *boolean*

*Defined in [responses/highlights.repository.highlights-tray.response.ts:83](https://github.com/dilame/instagram-private-api/blob/3e16058/src/responses/highlights.repository.highlights-tray.response.ts#L83)*

___

###  id

• **id**: *string*

*Defined in [responses/highlights.repository.highlights-tray.response.ts:61](https://github.com/dilame/instagram-private-api/blob/3e16058/src/responses/highlights.repository.highlights-tray.response.ts#L61)*

___

###  image_versions2

• **image_versions2**: *[HighlightsRepositoryHighlightsTrayResponseImage_versions2](_responses_highlights_repository_highlights_tray_response_.highlightsrepositoryhighlightstrayresponseimage_versions2.md)*

*Defined in [responses/highlights.repository.highlights-tray.response.ts:67](https://github.com/dilame/instagram-private-api/blob/3e16058/src/responses/highlights.repository.highlights-tray.response.ts#L67)*

___

###  is_dash_eligible

• **is_dash_eligible**: *number*

*Defined in [responses/highlights.repository.highlights-tray.response.ts:70](https://github.com/dilame/instagram-private-api/blob/3e16058/src/responses/highlights.repository.highlights-tray.response.ts#L70)*

___

###  like_count

• **like_count**: *number*

*Defined in [responses/highlights.repository.highlights-tray.response.ts:94](https://github.com/dilame/instagram-private-api/blob/3e16058/src/responses/highlights.repository.highlights-tray.response.ts#L94)*

___

###  max_num_visible_preview_comments

• **max_num_visible_preview_comments**: *number*

*Defined in [responses/highlights.repository.highlights-tray.response.ts:85](https://github.com/dilame/instagram-private-api/blob/3e16058/src/responses/highlights.repository.highlights-tray.response.ts#L85)*

___

###  media_cropping_info

• **media_cropping_info**: *[HighlightsRepositoryHighlightsTrayResponseMedia_cropping_info](_responses_highlights_repository_highlights_tray_response_.highlightsrepositoryhighlightstrayresponsemedia_cropping_info.md)*

*Defined in [responses/highlights.repository.highlights-tray.response.ts:92](https://github.com/dilame/instagram-private-api/blob/3e16058/src/responses/highlights.repository.highlights-tray.response.ts#L92)*

___

###  media_type

• **media_type**: *number*

*Defined in [responses/highlights.repository.highlights-tray.response.ts:63](https://github.com/dilame/instagram-private-api/blob/3e16058/src/responses/highlights.repository.highlights-tray.response.ts#L63)*

___

###  nearly_complete_copyright_match

• **nearly_complete_copyright_match**: *boolean*

*Defined in [responses/highlights.repository.highlights-tray.response.ts:91](https://github.com/dilame/instagram-private-api/blob/3e16058/src/responses/highlights.repository.highlights-tray.response.ts#L91)*

___

###  next_max_id

• **next_max_id**: *string*

*Defined in [responses/highlights.repository.highlights-tray.response.ts:84](https://github.com/dilame/instagram-private-api/blob/3e16058/src/responses/highlights.repository.highlights-tray.response.ts#L84)*

___

###  number_of_qualities

• **number_of_qualities**: *number*

*Defined in [responses/highlights.repository.highlights-tray.response.ts:73](https://github.com/dilame/instagram-private-api/blob/3e16058/src/responses/highlights.repository.highlights-tray.response.ts#L73)*

___

###  organic_tracking_token

• **organic_tracking_token**: *string*

*Defined in [responses/highlights.repository.highlights-tray.response.ts:99](https://github.com/dilame/instagram-private-api/blob/3e16058/src/responses/highlights.repository.highlights-tray.response.ts#L99)*

___

###  original_height

• **original_height**: *number*

*Defined in [responses/highlights.repository.highlights-tray.response.ts:69](https://github.com/dilame/instagram-private-api/blob/3e16058/src/responses/highlights.repository.highlights-tray.response.ts#L69)*

___

###  original_width

• **original_width**: *number*

*Defined in [responses/highlights.repository.highlights-tray.response.ts:68](https://github.com/dilame/instagram-private-api/blob/3e16058/src/responses/highlights.repository.highlights-tray.response.ts#L68)*

___

###  photo_of_you

• **photo_of_you**: *boolean*

*Defined in [responses/highlights.repository.highlights-tray.response.ts:96](https://github.com/dilame/instagram-private-api/blob/3e16058/src/responses/highlights.repository.highlights-tray.response.ts#L96)*

___

###  pk

• **pk**: *string*

*Defined in [responses/highlights.repository.highlights-tray.response.ts:60](https://github.com/dilame/instagram-private-api/blob/3e16058/src/responses/highlights.repository.highlights-tray.response.ts#L60)*

___

###  preview_comments

• **preview_comments**: *[HighlightsRepositoryHighlightsTrayResponsePreviewCommentsItem](_responses_highlights_repository_highlights_tray_response_.highlightsrepositoryhighlightstrayresponsepreviewcommentsitem.md)[]*

*Defined in [responses/highlights.repository.highlights-tray.response.ts:86](https://github.com/dilame/instagram-private-api/blob/3e16058/src/responses/highlights.repository.highlights-tray.response.ts#L86)*

___

###  product_type

• **product_type**: *string*

*Defined in [responses/highlights.repository.highlights-tray.response.ts:90](https://github.com/dilame/instagram-private-api/blob/3e16058/src/responses/highlights.repository.highlights-tray.response.ts#L90)*

___

###  taken_at

• **taken_at**: *number*

*Defined in [responses/highlights.repository.highlights-tray.response.ts:59](https://github.com/dilame/instagram-private-api/blob/3e16058/src/responses/highlights.repository.highlights-tray.response.ts#L59)*

___

###  thumbnails

• **thumbnails**: *[HighlightsRepositoryHighlightsTrayResponseThumbnails](_responses_highlights_repository_highlights_tray_response_.highlightsrepositoryhighlightstrayresponsethumbnails.md)*

*Defined in [responses/highlights.repository.highlights-tray.response.ts:93](https://github.com/dilame/instagram-private-api/blob/3e16058/src/responses/highlights.repository.highlights-tray.response.ts#L93)*

___

###  title

• **title**: *string*

*Defined in [responses/highlights.repository.highlights-tray.response.ts:89](https://github.com/dilame/instagram-private-api/blob/3e16058/src/responses/highlights.repository.highlights-tray.response.ts#L89)*

___

###  user

• **user**: *[HighlightsRepositoryHighlightsTrayResponseUser](_responses_highlights_repository_highlights_tray_response_.highlightsrepositoryhighlightstrayresponseuser.md)*

*Defined in [responses/highlights.repository.highlights-tray.response.ts:78](https://github.com/dilame/instagram-private-api/blob/3e16058/src/responses/highlights.repository.highlights-tray.response.ts#L78)*

___

###  video_codec

• **video_codec**: *string*

*Defined in [responses/highlights.repository.highlights-tray.response.ts:72](https://github.com/dilame/instagram-private-api/blob/3e16058/src/responses/highlights.repository.highlights-tray.response.ts#L72)*

___

###  video_dash_manifest

• **video_dash_manifest**: *string*

*Defined in [responses/highlights.repository.highlights-tray.response.ts:71](https://github.com/dilame/instagram-private-api/blob/3e16058/src/responses/highlights.repository.highlights-tray.response.ts#L71)*

___

###  video_duration

• **video_duration**: *number*

*Defined in [responses/highlights.repository.highlights-tray.response.ts:76](https://github.com/dilame/instagram-private-api/blob/3e16058/src/responses/highlights.repository.highlights-tray.response.ts#L76)*

___

###  video_versions

• **video_versions**: *[HighlightsRepositoryHighlightsTrayResponseVideoVersionsItem](_responses_highlights_repository_highlights_tray_response_.highlightsrepositoryhighlightstrayresponsevideoversionsitem.md)[]*

*Defined in [responses/highlights.repository.highlights-tray.response.ts:74](https://github.com/dilame/instagram-private-api/blob/3e16058/src/responses/highlights.repository.highlights-tray.response.ts#L74)*

___

###  view_count

• **view_count**: *number*

*Defined in [responses/highlights.repository.highlights-tray.response.ts:77](https://github.com/dilame/instagram-private-api/blob/3e16058/src/responses/highlights.repository.highlights-tray.response.ts#L77)*