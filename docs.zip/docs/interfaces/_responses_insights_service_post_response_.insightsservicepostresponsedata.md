> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["responses/insights.service.post.response"](../modules/_responses_insights_service_post_response_.md) / [InsightsServicePostResponseData](_responses_insights_service_post_response_.insightsservicepostresponsedata.md) /

# Interface: InsightsServicePostResponseData

## Hierarchy

* **InsightsServicePostResponseData**

## Index

### Properties

* [media](_responses_insights_service_post_response_.insightsservicepostresponsedata.md#media)

## Properties

###  media

• **media**: *[InsightsServicePostResponseMedia](_responses_insights_service_post_response_.insightsservicepostresponsemedia.md)*

*Defined in [responses/insights.service.post.response.ts:5](https://github.com/dilame/instagram-private-api/blob/3e16058/src/responses/insights.service.post.response.ts#L5)*