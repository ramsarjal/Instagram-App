> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["responses/direct-thread.repository.approve-participant-request.response"](../modules/_responses_direct_thread_repository_approve_participant_request_response_.md) / [DirectThreadRepositoryApproveParticipantRequestResponseRootObject](_responses_direct_thread_repository_approve_participant_request_response_.directthreadrepositoryapproveparticipantrequestresponserootobject.md) /

# Interface: DirectThreadRepositoryApproveParticipantRequestResponseRootObject

## Hierarchy

* **DirectThreadRepositoryApproveParticipantRequestResponseRootObject**

## Index

### Properties

* [status](_responses_direct_thread_repository_approve_participant_request_response_.directthreadrepositoryapproveparticipantrequestresponserootobject.md#status)
* [thread](_responses_direct_thread_repository_approve_participant_request_response_.directthreadrepositoryapproveparticipantrequestresponserootobject.md#thread)

## Properties

###  status

• **status**: *string*

*Defined in [responses/direct-thread.repository.approve-participant-request.response.ts:3](https://github.com/dilame/instagram-private-api/blob/3e16058/src/responses/direct-thread.repository.approve-participant-request.response.ts#L3)*

___

###  thread

• **thread**: *[DirectThreadRepositoryApproveParticipantRequestResponseThread](_responses_direct_thread_repository_approve_participant_request_response_.directthreadrepositoryapproveparticipantrequestresponsethread.md)*

*Defined in [responses/direct-thread.repository.approve-participant-request.response.ts:2](https://github.com/dilame/instagram-private-api/blob/3e16058/src/responses/direct-thread.repository.approve-participant-request.response.ts#L2)*