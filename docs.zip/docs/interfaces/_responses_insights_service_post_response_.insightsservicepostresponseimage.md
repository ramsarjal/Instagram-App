> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["responses/insights.service.post.response"](../modules/_responses_insights_service_post_response_.md) / [InsightsServicePostResponseImage](_responses_insights_service_post_response_.insightsservicepostresponseimage.md) /

# Interface: InsightsServicePostResponseImage

## Hierarchy

* **InsightsServicePostResponseImage**

## Index

### Properties

* [height](_responses_insights_service_post_response_.insightsservicepostresponseimage.md#height)
* [width](_responses_insights_service_post_response_.insightsservicepostresponseimage.md#width)

## Properties

###  height

• **height**: *number*

*Defined in [responses/insights.service.post.response.ts:96](https://github.com/dilame/instagram-private-api/blob/3e16058/src/responses/insights.service.post.response.ts#L96)*

___

###  width

• **width**: *number*

*Defined in [responses/insights.service.post.response.ts:97](https://github.com/dilame/instagram-private-api/blob/3e16058/src/responses/insights.service.post.response.ts#L97)*