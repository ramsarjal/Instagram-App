> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["responses/tag.feed.response"](../modules/_responses_tag_feed_response_.md) / [TagFeedResponseImage_versions2](_responses_tag_feed_response_.tagfeedresponseimage_versions2.md) /

# Interface: TagFeedResponseImage_versions2

## Hierarchy

* **TagFeedResponseImage_versions2**

## Index

### Properties

* [candidates](_responses_tag_feed_response_.tagfeedresponseimage_versions2.md#candidates)

## Properties

###  candidates

• **candidates**: *[TagFeedResponseCandidatesItem](_responses_tag_feed_response_.tagfeedresponsecandidatesitem.md)[]*

*Defined in [responses/tag.feed.response.ts:77](https://github.com/dilame/instagram-private-api/blob/3e16058/src/responses/tag.feed.response.ts#L77)*