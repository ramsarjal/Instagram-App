> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["responses/highlights.repository.highlights-tray.response"](../modules/_responses_highlights_repository_highlights_tray_response_.md) / [HighlightsRepositoryHighlightsTrayResponseCandidatesItem](_responses_highlights_repository_highlights_tray_response_.highlightsrepositoryhighlightstrayresponsecandidatesitem.md) /

# Interface: HighlightsRepositoryHighlightsTrayResponseCandidatesItem

## Hierarchy

* **HighlightsRepositoryHighlightsTrayResponseCandidatesItem**

## Index

### Properties

* [estimated_scans_sizes](_responses_highlights_repository_highlights_tray_response_.highlightsrepositoryhighlightstrayresponsecandidatesitem.md#estimated_scans_sizes)
* [height](_responses_highlights_repository_highlights_tray_response_.highlightsrepositoryhighlightstrayresponsecandidatesitem.md#height)
* [url](_responses_highlights_repository_highlights_tray_response_.highlightsrepositoryhighlightstrayresponsecandidatesitem.md#url)
* [width](_responses_highlights_repository_highlights_tray_response_.highlightsrepositoryhighlightstrayresponsecandidatesitem.md#width)

## Properties

###  estimated_scans_sizes

• **estimated_scans_sizes**: *number[]*

*Defined in [responses/highlights.repository.highlights-tray.response.ts:108](https://github.com/dilame/instagram-private-api/blob/3e16058/src/responses/highlights.repository.highlights-tray.response.ts#L108)*

___

###  height

• **height**: *number*

*Defined in [responses/highlights.repository.highlights-tray.response.ts:106](https://github.com/dilame/instagram-private-api/blob/3e16058/src/responses/highlights.repository.highlights-tray.response.ts#L106)*

___

###  url

• **url**: *string*

*Defined in [responses/highlights.repository.highlights-tray.response.ts:107](https://github.com/dilame/instagram-private-api/blob/3e16058/src/responses/highlights.repository.highlights-tray.response.ts#L107)*

___

###  width

• **width**: *number*

*Defined in [responses/highlights.repository.highlights-tray.response.ts:105](https://github.com/dilame/instagram-private-api/blob/3e16058/src/responses/highlights.repository.highlights-tray.response.ts#L105)*