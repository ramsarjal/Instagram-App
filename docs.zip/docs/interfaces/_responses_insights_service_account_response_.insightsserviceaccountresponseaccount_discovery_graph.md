> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["responses/insights.service.account.response"](../modules/_responses_insights_service_account_response_.md) / [InsightsServiceAccountResponseAccount_discovery_graph](_responses_insights_service_account_response_.insightsserviceaccountresponseaccount_discovery_graph.md) /

# Interface: InsightsServiceAccountResponseAccount_discovery_graph

## Hierarchy

* **InsightsServiceAccountResponseAccount_discovery_graph**

## Index

### Properties

* [nodes](_responses_insights_service_account_response_.insightsserviceaccountresponseaccount_discovery_graph.md#nodes)

## Properties

###  nodes

• **nodes**: *[InsightsServiceAccountResponseNodesItem](_responses_insights_service_account_response_.insightsserviceaccountresponsenodesitem.md)[]*

*Defined in [responses/insights.service.account.response.ts:68](https://github.com/dilame/instagram-private-api/blob/3e16058/src/responses/insights.service.account.response.ts#L68)*