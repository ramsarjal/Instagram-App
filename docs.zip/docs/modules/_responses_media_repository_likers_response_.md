> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["responses/media.repository.likers.response"](_responses_media_repository_likers_response_.md) /

# External module: "responses/media.repository.likers.response"

## Index

### Interfaces

* [MediaRepositoryLikersResponseRootObject](../interfaces/_responses_media_repository_likers_response_.mediarepositorylikersresponserootobject.md)
* [MediaRepositoryLikersResponseUsersItem](../interfaces/_responses_media_repository_likers_response_.mediarepositorylikersresponseusersitem.md)