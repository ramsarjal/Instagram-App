> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["services/story.service"](_services_story_service_.md) /

# External module: "services/story.service"

## Index

### Classes

* [StoryService](../classes/_services_story_service_.storyservice.md)