> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["responses/live.comments.response"](_responses_live_comments_response_.md) /

# External module: "responses/live.comments.response"

## Index

### Interfaces

* [LiveCommentsResponseCommentsItem](../interfaces/_responses_live_comments_response_.livecommentsresponsecommentsitem.md)
* [LiveCommentsResponseRootObject](../interfaces/_responses_live_comments_response_.livecommentsresponserootobject.md)
* [LiveCommentsResponseSystemCommentsItem](../interfaces/_responses_live_comments_response_.livecommentsresponsesystemcommentsitem.md)
* [LiveCommentsResponseUser](../interfaces/_responses_live_comments_response_.livecommentsresponseuser.md)