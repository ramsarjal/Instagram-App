> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["errors/ig-inactive-user.error"](_errors_ig_inactive_user_error_.md) /

# External module: "errors/ig-inactive-user.error"

## Index

### Classes

* [IgInactiveUserError](../classes/_errors_ig_inactive_user_error_.iginactiveusererror.md)