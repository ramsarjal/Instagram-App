> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["responses/direct.repository.ranked-recipients.response"](_responses_direct_repository_ranked_recipients_response_.md) /

# External module: "responses/direct.repository.ranked-recipients.response"

## Index

### Interfaces

* [DirectRepositoryRankedRecipientsResponseRankedRecipientsItem](../interfaces/_responses_direct_repository_ranked_recipients_response_.directrepositoryrankedrecipientsresponserankedrecipientsitem.md)
* [DirectRepositoryRankedRecipientsResponseRootObject](../interfaces/_responses_direct_repository_ranked_recipients_response_.directrepositoryrankedrecipientsresponserootobject.md)
* [DirectRepositoryRankedRecipientsResponseThread](../interfaces/_responses_direct_repository_ranked_recipients_response_.directrepositoryrankedrecipientsresponsethread.md)
* [DirectRepositoryRankedRecipientsResponseUser](../interfaces/_responses_direct_repository_ranked_recipients_response_.directrepositoryrankedrecipientsresponseuser.md)
* [DirectRepositoryRankedRecipientsResponseUsersItem](../interfaces/_responses_direct_repository_ranked_recipients_response_.directrepositoryrankedrecipientsresponseusersitem.md)