> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["responses/music-genre.feed.response"](_responses_music_genre_feed_response_.md) /

# External module: "responses/music-genre.feed.response"

## Index

### Interfaces

* [MusicGenreFeedResponseItemsItem](../interfaces/_responses_music_genre_feed_response_.musicgenrefeedresponseitemsitem.md)
* [MusicGenreFeedResponsePage_info](../interfaces/_responses_music_genre_feed_response_.musicgenrefeedresponsepage_info.md)
* [MusicGenreFeedResponseRootObject](../interfaces/_responses_music_genre_feed_response_.musicgenrefeedresponserootobject.md)
* [MusicGenreFeedResponseTrack](../interfaces/_responses_music_genre_feed_response_.musicgenrefeedresponsetrack.md)