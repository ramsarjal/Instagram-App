> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["repositories/news.repository"](_repositories_news_repository_.md) /

# External module: "repositories/news.repository"

## Index

### Classes

* [NewsRepository](../classes/_repositories_news_repository_.newsrepository.md)