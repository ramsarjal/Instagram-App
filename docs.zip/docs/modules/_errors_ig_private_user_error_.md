> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["errors/ig-private-user.error"](_errors_ig_private_user_error_.md) /

# External module: "errors/ig-private-user.error"

## Index

### Classes

* [IgPrivateUserError](../classes/_errors_ig_private_user_error_.igprivateusererror.md)