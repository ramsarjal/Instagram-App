> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["repositories/live.repository"](_repositories_live_repository_.md) /

# External module: "repositories/live.repository"

## Index

### Classes

* [LiveRepository](../classes/_repositories_live_repository_.liverepository.md)