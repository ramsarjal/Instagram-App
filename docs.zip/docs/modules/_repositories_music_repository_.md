> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["repositories/music.repository"](_repositories_music_repository_.md) /

# External module: "repositories/music.repository"

## Index

### Classes

* [MusicRepository](../classes/_repositories_music_repository_.musicrepository.md)