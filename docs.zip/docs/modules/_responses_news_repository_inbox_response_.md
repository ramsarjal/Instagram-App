> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["responses/news.repository.inbox.response"](_responses_news_repository_inbox_response_.md) /

# External module: "responses/news.repository.inbox.response"

## Index

### Interfaces

* [NewsRepositoryInboxResponseAds_manager](../interfaces/_responses_news_repository_inbox_response_.newsrepositoryinboxresponseads_manager.md)
* [NewsRepositoryInboxResponseArgs](../interfaces/_responses_news_repository_inbox_response_.newsrepositoryinboxresponseargs.md)
* [NewsRepositoryInboxResponseAymf](../interfaces/_responses_news_repository_inbox_response_.newsrepositoryinboxresponseaymf.md)
* [NewsRepositoryInboxResponseBusiness_profile_reminder](../interfaces/_responses_news_repository_inbox_response_.newsrepositoryinboxresponsebusiness_profile_reminder.md)
* [NewsRepositoryInboxResponseCounts](../interfaces/_responses_news_repository_inbox_response_.newsrepositoryinboxresponsecounts.md)
* [NewsRepositoryInboxResponseHashtag_follow](../interfaces/_responses_news_repository_inbox_response_.newsrepositoryinboxresponsehashtag_follow.md)
* [NewsRepositoryInboxResponseItemsItem](../interfaces/_responses_news_repository_inbox_response_.newsrepositoryinboxresponseitemsitem.md)
* [NewsRepositoryInboxResponseLinksItem](../interfaces/_responses_news_repository_inbox_response_.newsrepositoryinboxresponselinksitem.md)
* [NewsRepositoryInboxResponseMediaItem](../interfaces/_responses_news_repository_inbox_response_.newsrepositoryinboxresponsemediaitem.md)
* [NewsRepositoryInboxResponseNewStoriesItem](../interfaces/_responses_news_repository_inbox_response_.newsrepositoryinboxresponsenewstoriesitem.md)
* [NewsRepositoryInboxResponseOldStoriesItem](../interfaces/_responses_news_repository_inbox_response_.newsrepositoryinboxresponseoldstoriesitem.md)
* [NewsRepositoryInboxResponsePartition](../interfaces/_responses_news_repository_inbox_response_.newsrepositoryinboxresponsepartition.md)
* [NewsRepositoryInboxResponseRootObject](../interfaces/_responses_news_repository_inbox_response_.newsrepositoryinboxresponserootobject.md)
* [NewsRepositoryInboxResponseTime_bucket](../interfaces/_responses_news_repository_inbox_response_.newsrepositoryinboxresponsetime_bucket.md)
* [NewsRepositoryInboxResponseUser](../interfaces/_responses_news_repository_inbox_response_.newsrepositoryinboxresponseuser.md)