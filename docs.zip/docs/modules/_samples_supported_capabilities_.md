> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["samples/supported-capabilities"](_samples_supported_capabilities_.md) /

# External module: "samples/supported-capabilities"