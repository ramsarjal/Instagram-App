> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["responses/music.repository.moods.response"](_responses_music_repository_moods_response_.md) /

# External module: "responses/music.repository.moods.response"

## Index

### Interfaces

* [MusicRepositoryMoodsResponseItemsItem](../interfaces/_responses_music_repository_moods_response_.musicrepositorymoodsresponseitemsitem.md)
* [MusicRepositoryMoodsResponseMood](../interfaces/_responses_music_repository_moods_response_.musicrepositorymoodsresponsemood.md)
* [MusicRepositoryMoodsResponseRootObject](../interfaces/_responses_music_repository_moods_response_.musicrepositorymoodsresponserootobject.md)