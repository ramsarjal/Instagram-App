> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["responses/discover.feed.response"](_responses_discover_feed_response_.md) /

# External module: "responses/discover.feed.response"

## Index

### Classes

* [DiscoverFeedResponseUser](../classes/_responses_discover_feed_response_.discoverfeedresponseuser.md)

### Interfaces

* [DiscoverFeedResponseNew_suggested_users](../interfaces/_responses_discover_feed_response_.discoverfeedresponsenew_suggested_users.md)
* [DiscoverFeedResponseRootObject](../interfaces/_responses_discover_feed_response_.discoverfeedresponserootobject.md)
* [DiscoverFeedResponseSuggested_users](../interfaces/_responses_discover_feed_response_.discoverfeedresponsesuggested_users.md)
* [DiscoverFeedResponseSuggestionsItem](../interfaces/_responses_discover_feed_response_.discoverfeedresponsesuggestionsitem.md)