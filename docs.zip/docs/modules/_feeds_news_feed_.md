> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["feeds/news.feed"](_feeds_news_feed_.md) /

# External module: "feeds/news.feed"

## Index

### Classes

* [NewsFeed](../classes/_feeds_news_feed_.newsfeed.md)