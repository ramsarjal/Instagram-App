> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["responses/music.repository.genres.response"](_responses_music_repository_genres_response_.md) /

# External module: "responses/music.repository.genres.response"

## Index

### Interfaces

* [MusicRepositoryGenresResponseGenre](../interfaces/_responses_music_repository_genres_response_.musicrepositorygenresresponsegenre.md)
* [MusicRepositoryGenresResponseItemsItem](../interfaces/_responses_music_repository_genres_response_.musicrepositorygenresresponseitemsitem.md)
* [MusicRepositoryGenresResponseRootObject](../interfaces/_responses_music_repository_genres_response_.musicrepositorygenresresponserootobject.md)