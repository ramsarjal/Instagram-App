> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["responses/insights.service.story.response"](_responses_insights_service_story_response_.md) /

# External module: "responses/insights.service.story.response"

## Index

### Interfaces

* [InsightsServiceStoryResponseData](../interfaces/_responses_insights_service_story_response_.insightsservicestoryresponsedata.md)
* [InsightsServiceStoryResponseInline_insights_node](../interfaces/_responses_insights_service_story_response_.insightsservicestoryresponseinline_insights_node.md)
* [InsightsServiceStoryResponseInstagram_actor](../interfaces/_responses_insights_service_story_response_.insightsservicestoryresponseinstagram_actor.md)
* [InsightsServiceStoryResponseMedia](../interfaces/_responses_insights_service_story_response_.insightsservicestoryresponsemedia.md)
* [InsightsServiceStoryResponseRootObject](../interfaces/_responses_insights_service_story_response_.insightsservicestoryresponserootobject.md)