> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["feeds/saved.feed"](_feeds_saved_feed_.md) /

# External module: "feeds/saved.feed"

## Index

### Classes

* [SavedFeed](../classes/_feeds_saved_feed_.savedfeed.md)