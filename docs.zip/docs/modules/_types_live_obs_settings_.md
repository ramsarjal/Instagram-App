> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["types/live.obs-settings"](_types_live_obs_settings_.md) /

# External module: "types/live.obs-settings"

## Index

### Interfaces

* [LiveRtmpSettings](../interfaces/_types_live_obs_settings_.livertmpsettings.md)