> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["types/posting.video.options"](_types_posting_video_options_.md) /

# External module: "types/posting.video.options"

## Index

### Interfaces

* [PostingStoryVideoOptions](../interfaces/_types_posting_video_options_.postingstoryvideooptions.md)
* [PostingVideoOptions](../interfaces/_types_posting_video_options_.postingvideooptions.md)