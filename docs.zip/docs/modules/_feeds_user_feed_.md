> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["feeds/user.feed"](_feeds_user_feed_.md) /

# External module: "feeds/user.feed"

## Index

### Classes

* [UserFeed](../classes/_feeds_user_feed_.userfeed.md)