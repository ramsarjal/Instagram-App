> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["types/media.configure.options"](_types_media_configure_options_.md) /

# External module: "types/media.configure.options"

## Index

### Interfaces

* [MediaConfigureOptions](../interfaces/_types_media_configure_options_.mediaconfigureoptions.md)
* [MediaConfigureTimelineOptions](../interfaces/_types_media_configure_options_.mediaconfiguretimelineoptions.md)
* [MediaLocation](../interfaces/_types_media_configure_options_.medialocation.md)