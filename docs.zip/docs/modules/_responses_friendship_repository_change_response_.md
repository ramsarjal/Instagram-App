> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["responses/friendship.repository.change.response"](_responses_friendship_repository_change_response_.md) /

# External module: "responses/friendship.repository.change.response"

## Index

### Interfaces

* [FriendshipRepositoryChangeResponseFriendship_status](../interfaces/_responses_friendship_repository_change_response_.friendshiprepositorychangeresponsefriendship_status.md)
* [FriendshipRepositoryChangeResponseRootObject](../interfaces/_responses_friendship_repository_change_response_.friendshiprepositorychangeresponserootobject.md)