> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["repositories/challenge.repository"](_repositories_challenge_repository_.md) /

# External module: "repositories/challenge.repository"

## Index

### Classes

* [ChallengeRepository](../classes/_repositories_challenge_repository_.challengerepository.md)