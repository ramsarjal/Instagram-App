> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["responses/direct.repository.get-presence.response"](_responses_direct_repository_get_presence_response_.md) /

# External module: "responses/direct.repository.get-presence.response"

## Index

### Interfaces

* [DirectRepositoryGetPresenceResponseRootObject](../interfaces/_responses_direct_repository_get_presence_response_.directrepositorygetpresenceresponserootobject.md)