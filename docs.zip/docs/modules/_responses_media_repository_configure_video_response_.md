> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["responses/media.repository.configure-video.response"](_responses_media_repository_configure_video_response_.md) /

# External module: "responses/media.repository.configure-video.response"

## Index

### Interfaces

* [MediaRepositoryConfigureVideoResponseCandidatesItem](../interfaces/_responses_media_repository_configure_video_response_.mediarepositoryconfigurevideoresponsecandidatesitem.md)
* [MediaRepositoryConfigureVideoResponseFb_user_tags](../interfaces/_responses_media_repository_configure_video_response_.mediarepositoryconfigurevideoresponsefb_user_tags.md)
* [MediaRepositoryConfigureVideoResponseImage_versions2](../interfaces/_responses_media_repository_configure_video_response_.mediarepositoryconfigurevideoresponseimage_versions2.md)
* [MediaRepositoryConfigureVideoResponseInItem](../interfaces/_responses_media_repository_configure_video_response_.mediarepositoryconfigurevideoresponseinitem.md)
* [MediaRepositoryConfigureVideoResponseMedia](../interfaces/_responses_media_repository_configure_video_response_.mediarepositoryconfigurevideoresponsemedia.md)
* [MediaRepositoryConfigureVideoResponseRootObject](../interfaces/_responses_media_repository_configure_video_response_.mediarepositoryconfigurevideoresponserootobject.md)
* [MediaRepositoryConfigureVideoResponseUser](../interfaces/_responses_media_repository_configure_video_response_.mediarepositoryconfigurevideoresponseuser.md)
* [MediaRepositoryConfigureVideoResponseUsertags](../interfaces/_responses_media_repository_configure_video_response_.mediarepositoryconfigurevideoresponseusertags.md)