> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["responses/music.repository.lyrics.response"](_responses_music_repository_lyrics_response_.md) /

# External module: "responses/music.repository.lyrics.response"

## Index

### Interfaces

* [MusicRepositoryLyricsResponseLyrics](../interfaces/_responses_music_repository_lyrics_response_.musicrepositorylyricsresponselyrics.md)
* [MusicRepositoryLyricsResponsePhrasesItem](../interfaces/_responses_music_repository_lyrics_response_.musicrepositorylyricsresponsephrasesitem.md)
* [MusicRepositoryLyricsResponseRootObject](../interfaces/_responses_music_repository_lyrics_response_.musicrepositorylyricsresponserootobject.md)