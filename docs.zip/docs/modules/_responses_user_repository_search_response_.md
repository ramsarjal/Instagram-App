> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["responses/user.repository.search.response"](_responses_user_repository_search_response_.md) /

# External module: "responses/user.repository.search.response"

## Index

### Interfaces

* [UserRepositorySearchResponseFriendship_status](../interfaces/_responses_user_repository_search_response_.userrepositorysearchresponsefriendship_status.md)
* [UserRepositorySearchResponseRootObject](../interfaces/_responses_user_repository_search_response_.userrepositorysearchresponserootobject.md)
* [UserRepositorySearchResponseUsersItem](../interfaces/_responses_user_repository_search_response_.userrepositorysearchresponseusersitem.md)