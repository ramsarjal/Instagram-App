> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["feeds/reels-media.feed"](_feeds_reels_media_feed_.md) /

# External module: "feeds/reels-media.feed"

## Index

### Classes

* [ReelsMediaFeed](../classes/_feeds_reels_media_feed_.reelsmediafeed.md)