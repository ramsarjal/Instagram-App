> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["responses/location.repository.search.response"](_responses_location_repository_search_response_.md) /

# External module: "responses/location.repository.search.response"

## Index

### Interfaces

* [LocationRepositorySearchResponseRootObject](../interfaces/_responses_location_repository_search_response_.locationrepositorysearchresponserootobject.md)
* [LocationRepositorySearchResponseVenuesItem](../interfaces/_responses_location_repository_search_response_.locationrepositorysearchresponsevenuesitem.md)