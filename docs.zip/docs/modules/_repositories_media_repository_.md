> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["repositories/media.repository"](_repositories_media_repository_.md) /

# External module: "repositories/media.repository"

## Index

### Classes

* [MediaRepository](../classes/_repositories_media_repository_.mediarepository.md)