> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["errors/ig-login-required.error"](_errors_ig_login_required_error_.md) /

# External module: "errors/ig-login-required.error"

## Index

### Classes

* [IgLoginRequiredError](../classes/_errors_ig_login_required_error_.igloginrequirederror.md)