> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["errors/ig-exact-user-not-found-error"](_errors_ig_exact_user_not_found_error_.md) /

# External module: "errors/ig-exact-user-not-found-error"

## Index

### Classes

* [IgExactUserNotFoundError](../classes/_errors_ig_exact_user_not_found_error_.igexactusernotfounderror.md)