> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["responses/direct.repository.create-group-thread.response"](_responses_direct_repository_create_group_thread_response_.md) /

# External module: "responses/direct.repository.create-group-thread.response"

## Index

### Interfaces

* [DirectRepositoryCreateGroupThreadResponseFriendshipStatus](../interfaces/_responses_direct_repository_create_group_thread_response_.directrepositorycreategroupthreadresponsefriendshipstatus.md)
* [DirectRepositoryCreateGroupThreadResponseInviter](../interfaces/_responses_direct_repository_create_group_thread_response_.directrepositorycreategroupthreadresponseinviter.md)
* [DirectRepositoryCreateGroupThreadResponseRootObject](../interfaces/_responses_direct_repository_create_group_thread_response_.directrepositorycreategroupthreadresponserootobject.md)
* [DirectRepositoryCreateGroupThreadResponseUsersItem](../interfaces/_responses_direct_repository_create_group_thread_response_.directrepositorycreategroupthreadresponseusersitem.md)