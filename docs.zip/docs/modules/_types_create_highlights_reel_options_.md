> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["types/create-highlights-reel.options"](_types_create_highlights_reel_options_.md) /

# External module: "types/create-highlights-reel.options"

## Index

### Interfaces

* [CreateHighlightsReelOptions](../interfaces/_types_create_highlights_reel_options_.createhighlightsreeloptions.md)