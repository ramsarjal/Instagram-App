> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["types/stories.types"](_types_stories_types_.md) /

# External module: "types/stories.types"

## Index

### Interfaces

* [StoryServiceSeenInputItems](../interfaces/_types_stories_types_.storyserviceseeninputitems.md)
* [StoryServiceSeenInputReels](../interfaces/_types_stories_types_.storyserviceseeninputreels.md)

### Type aliases

* [StoryServiceInput](_types_stories_types_.md#storyserviceinput)

## Type aliases

###  StoryServiceInput

Ƭ **StoryServiceInput**: *[StoryServiceSeenInputItems](../interfaces/_types_stories_types_.storyserviceseeninputitems.md)[] | [StoryServiceSeenInputReels](../interfaces/_types_stories_types_.storyserviceseeninputreels.md)*

*Defined in [types/stories.types.ts:13](https://github.com/dilame/instagram-private-api/blob/3e16058/src/types/stories.types.ts#L13)*