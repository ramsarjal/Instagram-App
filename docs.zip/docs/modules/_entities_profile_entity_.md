> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["entities/profile.entity"](_entities_profile_entity_.md) /

# External module: "entities/profile.entity"

## Index

### Classes

* [ProfileEntity](../classes/_entities_profile_entity_.profileentity.md)