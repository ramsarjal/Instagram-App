> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["errors/ig-login-invalid-user.error"](_errors_ig_login_invalid_user_error_.md) /

# External module: "errors/ig-login-invalid-user.error"

## Index

### Classes

* [IgLoginInvalidUserError](../classes/_errors_ig_login_invalid_user_error_.iglogininvalidusererror.md)