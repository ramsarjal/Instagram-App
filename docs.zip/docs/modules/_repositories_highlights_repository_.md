> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["repositories/highlights.repository"](_repositories_highlights_repository_.md) /

# External module: "repositories/highlights.repository"

## Index

### Classes

* [HighlightsRepository](../classes/_repositories_highlights_repository_.highlightsrepository.md)