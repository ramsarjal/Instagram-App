> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["repositories/linked-account.repository"](_repositories_linked_account_repository_.md) /

# External module: "repositories/linked-account.repository"

## Index

### Classes

* [LinkedAccountRepository](../classes/_repositories_linked_account_repository_.linkedaccountrepository.md)