> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["repositories/launcher.repository"](_repositories_launcher_repository_.md) /

# External module: "repositories/launcher.repository"

## Index

### Classes

* [LauncherRepository](../classes/_repositories_launcher_repository_.launcherrepository.md)