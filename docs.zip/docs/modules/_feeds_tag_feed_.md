> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["feeds/tag.feed"](_feeds_tag_feed_.md) /

# External module: "feeds/tag.feed"

## Index

### Classes

* [TagFeed](../classes/_feeds_tag_feed_.tagfeed.md)