> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["responses/spam.response"](_responses_spam_response_.md) /

# External module: "responses/spam.response"

## Index

### Interfaces

* [SpamResponse](../interfaces/_responses_spam_response_.spamresponse.md)