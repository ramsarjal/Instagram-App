> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["feeds/reels-tray.feed"](_feeds_reels_tray_feed_.md) /

# External module: "feeds/reels-tray.feed"

## Index

### Classes

* [ReelsTrayFeed](../classes/_feeds_reels_tray_feed_.reelstrayfeed.md)