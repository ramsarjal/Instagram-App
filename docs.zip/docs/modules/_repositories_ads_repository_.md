> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["repositories/ads.repository"](_repositories_ads_repository_.md) /

# External module: "repositories/ads.repository"

## Index

### Classes

* [AdsRepository](../classes/_repositories_ads_repository_.adsrepository.md)