> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["types/posting.album.options"](_types_posting_album_options_.md) /

# External module: "types/posting.album.options"

## Index

### Interfaces

* [PostingAlbumItem](../interfaces/_types_posting_album_options_.postingalbumitem.md)
* [PostingAlbumOptions](../interfaces/_types_posting_album_options_.postingalbumoptions.md)
* [PostingAlbumPhotoItem](../interfaces/_types_posting_album_options_.postingalbumphotoitem.md)
* [PostingAlbumVideoItem](../interfaces/_types_posting_album_options_.postingalbumvideoitem.md)