> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["responses/live.like.response"](_responses_live_like_response_.md) /

# External module: "responses/live.like.response"

## Index

### Interfaces

* [LiveLikeResponseRootObject](../interfaces/_responses_live_like_response_.livelikeresponserootobject.md)