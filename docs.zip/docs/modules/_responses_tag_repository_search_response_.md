> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["responses/tag.repository.search.response"](_responses_tag_repository_search_response_.md) /

# External module: "responses/tag.repository.search.response"

## Index

### Interfaces

* [TagRepositorySearchResponseResultsItem](../interfaces/_responses_tag_repository_search_response_.tagrepositorysearchresponseresultsitem.md)
* [TagRepositorySearchResponseRootObject](../interfaces/_responses_tag_repository_search_response_.tagrepositorysearchresponserootobject.md)