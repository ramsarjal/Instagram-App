> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["entities/direct-thread.entity"](_entities_direct_thread_entity_.md) /

# External module: "entities/direct-thread.entity"

## Index

### Classes

* [DirectThreadEntity](../classes/_entities_direct_thread_entity_.directthreadentity.md)