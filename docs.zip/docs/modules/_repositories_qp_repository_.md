> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["repositories/qp.repository"](_repositories_qp_repository_.md) /

# External module: "repositories/qp.repository"

## Index

### Classes

* [QpRepository](../classes/_repositories_qp_repository_.qprepository.md)