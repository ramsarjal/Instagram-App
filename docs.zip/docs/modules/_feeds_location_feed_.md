> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["feeds/location.feed"](_feeds_location_feed_.md) /

# External module: "feeds/location.feed"

## Index

### Classes

* [LocationFeed](../classes/_feeds_location_feed_.locationfeed.md)