> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["feeds/direct-thread.feed"](_feeds_direct_thread_feed_.md) /

# External module: "feeds/direct-thread.feed"

## Index

### Classes

* [DirectThreadFeed](../classes/_feeds_direct_thread_feed_.directthreadfeed.md)