> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["responses/account-following.feed.response"](_responses_account_following_feed_response_.md) /

# External module: "responses/account-following.feed.response"

## Index

### Classes

* [AccountFollowingFeedResponseUsersItem](../classes/_responses_account_following_feed_response_.accountfollowingfeedresponseusersitem.md)

### Interfaces

* [AccountFollowingFeedResponse](../interfaces/_responses_account_following_feed_response_.accountfollowingfeedresponse.md)