> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["responses/media.repository.configure.response"](_responses_media_repository_configure_response_.md) /

# External module: "responses/media.repository.configure.response"

## Index

### Interfaces

* [MediaRepositoryConfigureResponseCandidatesItem](../interfaces/_responses_media_repository_configure_response_.mediarepositoryconfigureresponsecandidatesitem.md)
* [MediaRepositoryConfigureResponseFb_user_tags](../interfaces/_responses_media_repository_configure_response_.mediarepositoryconfigureresponsefb_user_tags.md)
* [MediaRepositoryConfigureResponseImage_versions2](../interfaces/_responses_media_repository_configure_response_.mediarepositoryconfigureresponseimage_versions2.md)
* [MediaRepositoryConfigureResponseMedia](../interfaces/_responses_media_repository_configure_response_.mediarepositoryconfigureresponsemedia.md)
* [MediaRepositoryConfigureResponseRootObject](../interfaces/_responses_media_repository_configure_response_.mediarepositoryconfigureresponserootobject.md)
* [MediaRepositoryConfigureResponseUser](../interfaces/_responses_media_repository_configure_response_.mediarepositoryconfigureresponseuser.md)