> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["responses/tag.repository.section.response"](_responses_tag_repository_section_response_.md) /

# External module: "responses/tag.repository.section.response"

## Index

### Interfaces

* [TagRepositorySectionResponseRootObject](../interfaces/_responses_tag_repository_section_response_.tagrepositorysectionresponserootobject.md)
* [TagRepositorySectionResponsesectionsItem](../interfaces/_responses_tag_repository_section_response_.tagrepositorysectionresponsesectionsitem.md)