> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["errors/ig-checkpoint.error"](_errors_ig_checkpoint_error_.md) /

# External module: "errors/ig-checkpoint.error"

## Index

### Classes

* [IgCheckpointError](../classes/_errors_ig_checkpoint_error_.igcheckpointerror.md)