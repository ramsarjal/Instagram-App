> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["errors/ig-no-checkpoint.error"](_errors_ig_no_checkpoint_error_.md) /

# External module: "errors/ig-no-checkpoint.error"

## Index

### Classes

* [IgNoCheckpointError](../classes/_errors_ig_no_checkpoint_error_.ignocheckpointerror.md)