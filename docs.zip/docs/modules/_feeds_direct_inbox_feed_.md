> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["feeds/direct-inbox.feed"](_feeds_direct_inbox_feed_.md) /

# External module: "feeds/direct-inbox.feed"

## Index

### Classes

* [DirectInboxFeed](../classes/_feeds_direct_inbox_feed_.directinboxfeed.md)