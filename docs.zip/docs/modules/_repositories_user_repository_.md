> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["repositories/user.repository"](_repositories_user_repository_.md) /

# External module: "repositories/user.repository"

## Index

### Classes

* [UserRepository](../classes/_repositories_user_repository_.userrepository.md)