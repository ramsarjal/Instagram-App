> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["repositories/zr.repository"](_repositories_zr_repository_.md) /

# External module: "repositories/zr.repository"

## Index

### Classes

* [ZrRepository](../classes/_repositories_zr_repository_.zrrepository.md)