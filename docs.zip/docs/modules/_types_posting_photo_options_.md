> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["types/posting.photo.options"](_types_posting_photo_options_.md) /

# External module: "types/posting.photo.options"

## Index

### Interfaces

* [PostingPhotoOptions](../interfaces/_types_posting_photo_options_.postingphotooptions.md)
* [PostingStoryPhotoOptions](../interfaces/_types_posting_photo_options_.postingstoryphotooptions.md)