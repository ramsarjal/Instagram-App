> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["responses/restrict-action.repository.restrict.response"](_responses_restrict_action_repository_restrict_response_.md) /

# External module: "responses/restrict-action.repository.restrict.response"

## Index

### Interfaces

* [RestrictActionRepositoryRestrictResponseFriendship_status](../interfaces/_responses_restrict_action_repository_restrict_response_.restrictactionrepositoryrestrictresponsefriendship_status.md)
* [RestrictActionRepositoryRestrictResponseRootObject](../interfaces/_responses_restrict_action_repository_restrict_response_.restrictactionrepositoryrestrictresponserootobject.md)
* [RestrictActionRepositoryRestrictResponseUsersItem](../interfaces/_responses_restrict_action_repository_restrict_response_.restrictactionrepositoryrestrictresponseusersitem.md)