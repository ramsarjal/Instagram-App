> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["responses/live.heartbeat-viewer-count.response"](_responses_live_heartbeat_viewer_count_response_.md) /

# External module: "responses/live.heartbeat-viewer-count.response"

## Index

### Interfaces

* [LiveHeartbeatViewerCountResponseRootObject](../interfaces/_responses_live_heartbeat_viewer_count_response_.liveheartbeatviewercountresponserootobject.md)