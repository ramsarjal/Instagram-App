> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["feeds/music-search.feed"](_feeds_music_search_feed_.md) /

# External module: "feeds/music-search.feed"

## Index

### Classes

* [MusicSearchFeed](../classes/_feeds_music_search_feed_.musicsearchfeed.md)