> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["feeds/music-trending.feed"](_feeds_music_trending_feed_.md) /

# External module: "feeds/music-trending.feed"

## Index

### Classes

* [MusicTrendingFeed](../classes/_feeds_music_trending_feed_.musictrendingfeed.md)