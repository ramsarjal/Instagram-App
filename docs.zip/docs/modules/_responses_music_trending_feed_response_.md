> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["responses/music-trending.feed.response"](_responses_music_trending_feed_response_.md) /

# External module: "responses/music-trending.feed.response"

## Index

### Interfaces

* [MusicTrendingFeedResponseItemsItem](../interfaces/_responses_music_trending_feed_response_.musictrendingfeedresponseitemsitem.md)
* [MusicTrendingFeedResponsePage_info](../interfaces/_responses_music_trending_feed_response_.musictrendingfeedresponsepage_info.md)
* [MusicTrendingFeedResponseRootObject](../interfaces/_responses_music_trending_feed_response_.musictrendingfeedresponserootobject.md)
* [MusicTrendingFeedResponseTrack](../interfaces/_responses_music_trending_feed_response_.musictrendingfeedresponsetrack.md)