> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["responses/live.info.response"](_responses_live_info_response_.md) /

# External module: "responses/live.info.response"

## Index

### Interfaces

* [LiveInfoResponseBroadcast_owner](../interfaces/_responses_live_info_response_.liveinforesponsebroadcast_owner.md)
* [LiveInfoResponseFriendship_status](../interfaces/_responses_live_info_response_.liveinforesponsefriendship_status.md)
* [LiveInfoResponseRootObject](../interfaces/_responses_live_info_response_.liveinforesponserootobject.md)