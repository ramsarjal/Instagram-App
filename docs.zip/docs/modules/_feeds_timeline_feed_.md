> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["feeds/timeline.feed"](_feeds_timeline_feed_.md) /

# External module: "feeds/timeline.feed"

## Index

### Classes

* [TimelineFeed](../classes/_feeds_timeline_feed_.timelinefeed.md)