> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["responses/address-book.repository.link.response"](_responses_address_book_repository_link_response_.md) /

# External module: "responses/address-book.repository.link.response"

## Index

### Interfaces

* [AddressBookRepositoryLinkResponseRootObject](../interfaces/_responses_address_book_repository_link_response_.addressbookrepositorylinkresponserootobject.md)
* [AddressBookRepositoryLinkResponseUsersItem](../interfaces/_responses_address_book_repository_link_response_.addressbookrepositorylinkresponseusersitem.md)