> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["types/media.configure-story.options"](_types_media_configure_story_options_.md) /

# External module: "types/media.configure-story.options"

## Index

### Interfaces

* [MediaConfigureStoryBaseOptions](../interfaces/_types_media_configure_story_options_.mediaconfigurestorybaseoptions.md)
* [MediaConfigureStoryPhotoOptions](../interfaces/_types_media_configure_story_options_.mediaconfigurestoryphotooptions.md)
* [MediaConfigureStoryVideoOptions](../interfaces/_types_media_configure_story_options_.mediaconfigurestoryvideooptions.md)
* [StoryAttachedMedia](../interfaces/_types_media_configure_story_options_.storyattachedmedia.md)
* [StoryChat](../interfaces/_types_media_configure_story_options_.storychat.md)
* [StoryCountdown](../interfaces/_types_media_configure_story_options_.storycountdown.md)
* [StoryCta](../interfaces/_types_media_configure_story_options_.storycta.md)
* [StoryHashtag](../interfaces/_types_media_configure_story_options_.storyhashtag.md)
* [StoryLocation](../interfaces/_types_media_configure_story_options_.storylocation.md)
* [StoryMention](../interfaces/_types_media_configure_story_options_.storymention.md)
* [StoryPoll](../interfaces/_types_media_configure_story_options_.storypoll.md)
* [StoryPollTallie](../interfaces/_types_media_configure_story_options_.storypolltallie.md)
* [StoryQuestion](../interfaces/_types_media_configure_story_options_.storyquestion.md)
* [StoryQuiz](../interfaces/_types_media_configure_story_options_.storyquiz.md)
* [StorySlider](../interfaces/_types_media_configure_story_options_.storyslider.md)
* [StorySticker](../interfaces/_types_media_configure_story_options_.storysticker.md)