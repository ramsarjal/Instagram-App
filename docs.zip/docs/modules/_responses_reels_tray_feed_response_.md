> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["responses/reels-tray.feed.response"](_responses_reels_tray_feed_response_.md) /

# External module: "responses/reels-tray.feed.response"

## Index

### Interfaces

* [ReelsTrayFeedResponseAttribution](../interfaces/_responses_reels_tray_feed_response_.reelstrayfeedresponseattribution.md)
* [ReelsTrayFeedResponseBroadcast_owner](../interfaces/_responses_reels_tray_feed_response_.reelstrayfeedresponsebroadcast_owner.md)
* [ReelsTrayFeedResponseBroadcastsItem](../interfaces/_responses_reels_tray_feed_response_.reelstrayfeedresponsebroadcastsitem.md)
* [ReelsTrayFeedResponseCandidatesItem](../interfaces/_responses_reels_tray_feed_response_.reelstrayfeedresponsecandidatesitem.md)
* [ReelsTrayFeedResponseCreative_config](../interfaces/_responses_reels_tray_feed_response_.reelstrayfeedresponsecreative_config.md)
* [ReelsTrayFeedResponseFriendship_status](../interfaces/_responses_reels_tray_feed_response_.reelstrayfeedresponsefriendship_status.md)
* [ReelsTrayFeedResponseImage_versions2](../interfaces/_responses_reels_tray_feed_response_.reelstrayfeedresponseimage_versions2.md)
* [ReelsTrayFeedResponseItemsItem](../interfaces/_responses_reels_tray_feed_response_.reelstrayfeedresponseitemsitem.md)
* [ReelsTrayFeedResponseLocation](../interfaces/_responses_reels_tray_feed_response_.reelstrayfeedresponselocation.md)
* [ReelsTrayFeedResponsePoll_sticker](../interfaces/_responses_reels_tray_feed_response_.reelstrayfeedresponsepoll_sticker.md)
* [ReelsTrayFeedResponseQuestion_sticker](../interfaces/_responses_reels_tray_feed_response_.reelstrayfeedresponsequestion_sticker.md)
* [ReelsTrayFeedResponseQuiz_sticker](../interfaces/_responses_reels_tray_feed_response_.reelstrayfeedresponsequiz_sticker.md)
* [ReelsTrayFeedResponseReelMentionsItem](../interfaces/_responses_reels_tray_feed_response_.reelstrayfeedresponsereelmentionsitem.md)
* [ReelsTrayFeedResponseRootObject](../interfaces/_responses_reels_tray_feed_response_.reelstrayfeedresponserootobject.md)
* [ReelsTrayFeedResponseStoryLocationsItem](../interfaces/_responses_reels_tray_feed_response_.reelstrayfeedresponsestorylocationsitem.md)
* [ReelsTrayFeedResponseStoryPollsItem](../interfaces/_responses_reels_tray_feed_response_.reelstrayfeedresponsestorypollsitem.md)
* [ReelsTrayFeedResponseStoryQuestionsItem](../interfaces/_responses_reels_tray_feed_response_.reelstrayfeedresponsestoryquestionsitem.md)
* [ReelsTrayFeedResponseStoryQuizsItem](../interfaces/_responses_reels_tray_feed_response_.reelstrayfeedresponsestoryquizsitem.md)
* [ReelsTrayFeedResponseTalliesItem](../interfaces/_responses_reels_tray_feed_response_.reelstrayfeedresponsetalliesitem.md)
* [ReelsTrayFeedResponseTrayItem](../interfaces/_responses_reels_tray_feed_response_.reelstrayfeedresponsetrayitem.md)
* [ReelsTrayFeedResponseUser](../interfaces/_responses_reels_tray_feed_response_.reelstrayfeedresponseuser.md)
* [ReelsTrayFeedResponseVideoVersionsItem](../interfaces/_responses_reels_tray_feed_response_.reelstrayfeedresponsevideoversionsitem.md)