> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["responses/stories-insights.feed.response"](_responses_stories_insights_feed_response_.md) /

# External module: "responses/stories-insights.feed.response"

## Index

### Interfaces

* [StoriesInsightsFeedResponseBusiness_manager](../interfaces/_responses_stories_insights_feed_response_.storiesinsightsfeedresponsebusiness_manager.md)
* [StoriesInsightsFeedResponseData](../interfaces/_responses_stories_insights_feed_response_.storiesinsightsfeedresponsedata.md)
* [StoriesInsightsFeedResponseEdgesItem](../interfaces/_responses_stories_insights_feed_response_.storiesinsightsfeedresponseedgesitem.md)
* [StoriesInsightsFeedResponseInline_insights_node](../interfaces/_responses_stories_insights_feed_response_.storiesinsightsfeedresponseinline_insights_node.md)
* [StoriesInsightsFeedResponseNode](../interfaces/_responses_stories_insights_feed_response_.storiesinsightsfeedresponsenode.md)
* [StoriesInsightsFeedResponsePage_info](../interfaces/_responses_stories_insights_feed_response_.storiesinsightsfeedresponsepage_info.md)
* [StoriesInsightsFeedResponseRootObject](../interfaces/_responses_stories_insights_feed_response_.storiesinsightsfeedresponserootobject.md)
* [StoriesInsightsFeedResponseStories](../interfaces/_responses_stories_insights_feed_response_.storiesinsightsfeedresponsestories.md)
* [StoriesInsightsFeedResponseStories_unit](../interfaces/_responses_stories_insights_feed_response_.storiesinsightsfeedresponsestories_unit.md)
* [StoriesInsightsFeedResponseUser](../interfaces/_responses_stories_insights_feed_response_.storiesinsightsfeedresponseuser.md)