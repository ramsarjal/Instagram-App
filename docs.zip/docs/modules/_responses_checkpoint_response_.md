> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["responses/checkpoint.response"](_responses_checkpoint_response_.md) /

# External module: "responses/checkpoint.response"

## Index

### Interfaces

* [CheckpointResponse](../interfaces/_responses_checkpoint_response_.checkpointresponse.md)
* [CheckpointResponseChallenge](../interfaces/_responses_checkpoint_response_.checkpointresponsechallenge.md)