> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["repositories/account.repository"](_repositories_account_repository_.md) /

# External module: "repositories/account.repository"

## Index

### Classes

* [AccountRepository](../classes/_repositories_account_repository_.accountrepository.md)