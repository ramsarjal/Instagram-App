> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["repositories/loom.repository"](_repositories_loom_repository_.md) /

# External module: "repositories/loom.repository"

## Index

### Classes

* [LoomRepository](../classes/_repositories_loom_repository_.loomrepository.md)