> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["repositories/address-book.repository"](_repositories_address_book_repository_.md) /

# External module: "repositories/address-book.repository"

## Index

### Classes

* [AddressBookRepository](../classes/_repositories_address_book_repository_.addressbookrepository.md)