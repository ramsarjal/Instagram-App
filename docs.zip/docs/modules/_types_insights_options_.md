> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["types/insights.options"](_types_insights_options_.md) /

# External module: "types/insights.options"

## Index

### Interfaces

* [AccountInsightsOptions](../interfaces/_types_insights_options_.accountinsightsoptions.md)
* [PostsInsightsFeedOptions](../interfaces/_types_insights_options_.postsinsightsfeedoptions.md)