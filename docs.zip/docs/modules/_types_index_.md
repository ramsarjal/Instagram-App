> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["types/index"](_types_index_.md) /

# External module: "types/index"