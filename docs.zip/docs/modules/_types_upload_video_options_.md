> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["types/upload.video.options"](_types_upload_video_options_.md) /

# External module: "types/upload.video.options"

## Index

### Interfaces

* [UploadVideoOptions](../interfaces/_types_upload_video_options_.uploadvideooptions.md)