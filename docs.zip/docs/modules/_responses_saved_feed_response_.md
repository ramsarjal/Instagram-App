> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["responses/saved.feed.response"](_responses_saved_feed_response_.md) /

# External module: "responses/saved.feed.response"

## Index

### Interfaces

* [SavedFeedResponseCandidatesItem](../interfaces/_responses_saved_feed_response_.savedfeedresponsecandidatesitem.md)
* [SavedFeedResponseCaption](../interfaces/_responses_saved_feed_response_.savedfeedresponsecaption.md)
* [SavedFeedResponseCarouselMediaItem](../interfaces/_responses_saved_feed_response_.savedfeedresponsecarouselmediaitem.md)
* [SavedFeedResponseFriendship_status](../interfaces/_responses_saved_feed_response_.savedfeedresponsefriendship_status.md)
* [SavedFeedResponseImage_versions2](../interfaces/_responses_saved_feed_response_.savedfeedresponseimage_versions2.md)
* [SavedFeedResponseInItem](../interfaces/_responses_saved_feed_response_.savedfeedresponseinitem.md)
* [SavedFeedResponseItemsItem](../interfaces/_responses_saved_feed_response_.savedfeedresponseitemsitem.md)
* [SavedFeedResponseMain_image](../interfaces/_responses_saved_feed_response_.savedfeedresponsemain_image.md)
* [SavedFeedResponseMedia](../interfaces/_responses_saved_feed_response_.savedfeedresponsemedia.md)
* [SavedFeedResponseMerchant](../interfaces/_responses_saved_feed_response_.savedfeedresponsemerchant.md)
* [SavedFeedResponsePreviewCommentsItem](../interfaces/_responses_saved_feed_response_.savedfeedresponsepreviewcommentsitem.md)
* [SavedFeedResponseProduct](../interfaces/_responses_saved_feed_response_.savedfeedresponseproduct.md)
* [SavedFeedResponseProduct_tags](../interfaces/_responses_saved_feed_response_.savedfeedresponseproduct_tags.md)
* [SavedFeedResponseRootObject](../interfaces/_responses_saved_feed_response_.savedfeedresponserootobject.md)
* [SavedFeedResponseThumbnail_image](../interfaces/_responses_saved_feed_response_.savedfeedresponsethumbnail_image.md)
* [SavedFeedResponseUser](../interfaces/_responses_saved_feed_response_.savedfeedresponseuser.md)
* [SavedFeedResponseUsertags](../interfaces/_responses_saved_feed_response_.savedfeedresponseusertags.md)
* [SavedFeedResponseVariantValuesItem](../interfaces/_responses_saved_feed_response_.savedfeedresponsevariantvaluesitem.md)
* [SavedFeedResponseVideoVersionsItem](../interfaces/_responses_saved_feed_response_.savedfeedresponsevideoversionsitem.md)