> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["feeds/stories-insights.feed"](_feeds_stories_insights_feed_.md) /

# External module: "feeds/stories-insights.feed"

## Index

### Classes

* [StoriesInsightsFeed](../classes/_feeds_stories_insights_feed_.storiesinsightsfeed.md)