> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["types/media.configure-sidecar.options"](_types_media_configure_sidecar_options_.md) /

# External module: "types/media.configure-sidecar.options"

## Index

### Interfaces

* [MediaConfigureSidecarItem](../interfaces/_types_media_configure_sidecar_options_.mediaconfiguresidecaritem.md)
* [MediaConfigureSidecarOptions](../interfaces/_types_media_configure_sidecar_options_.mediaconfiguresidecaroptions.md)
* [MediaConfigureSidecarVideoItem](../interfaces/_types_media_configure_sidecar_options_.mediaconfiguresidecarvideoitem.md)