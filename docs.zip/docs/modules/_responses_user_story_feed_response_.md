> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["responses/user-story.feed.response"](_responses_user_story_feed_response_.md) /

# External module: "responses/user-story.feed.response"

## Index

### Interfaces

* [UserStoryFeedResponseCandidatesItem](../interfaces/_responses_user_story_feed_response_.userstoryfeedresponsecandidatesitem.md)
* [UserStoryFeedResponseFriendship_status](../interfaces/_responses_user_story_feed_response_.userstoryfeedresponsefriendship_status.md)
* [UserStoryFeedResponseImage_versions2](../interfaces/_responses_user_story_feed_response_.userstoryfeedresponseimage_versions2.md)
* [UserStoryFeedResponseItemsItem](../interfaces/_responses_user_story_feed_response_.userstoryfeedresponseitemsitem.md)
* [UserStoryFeedResponseLocation](../interfaces/_responses_user_story_feed_response_.userstoryfeedresponselocation.md)
* [UserStoryFeedResponseReel](../interfaces/_responses_user_story_feed_response_.userstoryfeedresponsereel.md)
* [UserStoryFeedResponseRootObject](../interfaces/_responses_user_story_feed_response_.userstoryfeedresponserootobject.md)
* [UserStoryFeedResponseStoryLocationsItem](../interfaces/_responses_user_story_feed_response_.userstoryfeedresponsestorylocationsitem.md)
* [UserStoryFeedResponseUser](../interfaces/_responses_user_story_feed_response_.userstoryfeedresponseuser.md)
* [UserStoryFeedResponseVideoVersionsItem](../interfaces/_responses_user_story_feed_response_.userstoryfeedresponsevideoversionsitem.md)