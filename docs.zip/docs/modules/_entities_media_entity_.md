> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["entities/media.entity"](_entities_media_entity_.md) /

# External module: "entities/media.entity"

## Index

### Classes

* [MediaEntity](../classes/_entities_media_entity_.mediaentity.md)