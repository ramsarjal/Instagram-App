> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["feeds/music-mood.feed"](_feeds_music_mood_feed_.md) /

# External module: "feeds/music-mood.feed"

## Index

### Classes

* [MusicMoodFeed](../classes/_feeds_music_mood_feed_.musicmoodfeed.md)