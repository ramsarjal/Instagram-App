> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["errors/ig-response.error"](_errors_ig_response_error_.md) /

# External module: "errors/ig-response.error"

## Index

### Classes

* [IgResponseError](../classes/_errors_ig_response_error_.igresponseerror.md)