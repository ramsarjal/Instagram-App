> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["responses/insights.service.post.response"](_responses_insights_service_post_response_.md) /

# External module: "responses/insights.service.post.response"

## Index

### Interfaces

* [InsightsServicePostResponseActions](../interfaces/_responses_insights_service_post_response_.insightsservicepostresponseactions.md)
* [InsightsServicePostResponseData](../interfaces/_responses_insights_service_post_response_.insightsservicepostresponsedata.md)
* [InsightsServicePostResponseFollow_status](../interfaces/_responses_insights_service_post_response_.insightsservicepostresponsefollow_status.md)
* [InsightsServicePostResponseHashtags](../interfaces/_responses_insights_service_post_response_.insightsservicepostresponsehashtags.md)
* [InsightsServicePostResponseHashtags_impressions](../interfaces/_responses_insights_service_post_response_.insightsservicepostresponsehashtags_impressions.md)
* [InsightsServicePostResponseImage](../interfaces/_responses_insights_service_post_response_.insightsservicepostresponseimage.md)
* [InsightsServicePostResponseImpressions](../interfaces/_responses_insights_service_post_response_.insightsservicepostresponseimpressions.md)
* [InsightsServicePostResponseInline_insights_node](../interfaces/_responses_insights_service_post_response_.insightsservicepostresponseinline_insights_node.md)
* [InsightsServicePostResponseInstagram_actor](../interfaces/_responses_insights_service_post_response_.insightsservicepostresponseinstagram_actor.md)
* [InsightsServicePostResponseMedia](../interfaces/_responses_insights_service_post_response_.insightsservicepostresponsemedia.md)
* [InsightsServicePostResponseMetrics](../interfaces/_responses_insights_service_post_response_.insightsservicepostresponsemetrics.md)
* [InsightsServicePostResponseNodesItem](../interfaces/_responses_insights_service_post_response_.insightsservicepostresponsenodesitem.md)
* [InsightsServicePostResponseOrganic](../interfaces/_responses_insights_service_post_response_.insightsservicepostresponseorganic.md)
* [InsightsServicePostResponsePost](../interfaces/_responses_insights_service_post_response_.insightsservicepostresponsepost.md)
* [InsightsServicePostResponseProfile_actions](../interfaces/_responses_insights_service_post_response_.insightsservicepostresponseprofile_actions.md)
* [InsightsServicePostResponseReach](../interfaces/_responses_insights_service_post_response_.insightsservicepostresponsereach.md)
* [InsightsServicePostResponseRootObject](../interfaces/_responses_insights_service_post_response_.insightsservicepostresponserootobject.md)
* [InsightsServicePostResponseShare_count](../interfaces/_responses_insights_service_post_response_.insightsservicepostresponseshare_count.md)
* [InsightsServicePostResponseSurfaces](../interfaces/_responses_insights_service_post_response_.insightsservicepostresponsesurfaces.md)
* [InsightsServicePostResponseTray](../interfaces/_responses_insights_service_post_response_.insightsservicepostresponsetray.md)