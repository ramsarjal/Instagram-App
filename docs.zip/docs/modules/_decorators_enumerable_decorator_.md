> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["decorators/enumerable.decorator"](_decorators_enumerable_decorator_.md) /

# External module: "decorators/enumerable.decorator"

## Index

### Functions

* [Enumerable](_decorators_enumerable_decorator_.md#enumerable)

## Functions

###  Enumerable

▸ **Enumerable**(`value`: boolean): *`(Anonymous function)`*

*Defined in [decorators/enumerable.decorator.ts:1](https://github.com/dilame/instagram-private-api/blob/3e16058/src/decorators/enumerable.decorator.ts#L1)*

**Parameters:**

Name | Type |
------ | ------ |
`value` | boolean |

**Returns:** *`(Anonymous function)`*