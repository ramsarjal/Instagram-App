> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["repositories/restrict-action.repository"](_repositories_restrict_action_repository_.md) /

# External module: "repositories/restrict-action.repository"

## Index

### Classes

* [RestrictActionRepository](../classes/_repositories_restrict_action_repository_.restrictactionrepository.md)