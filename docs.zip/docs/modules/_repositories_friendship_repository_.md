> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["repositories/friendship.repository"](_repositories_friendship_repository_.md) /

# External module: "repositories/friendship.repository"

## Index

### Classes

* [FriendshipRepository](../classes/_repositories_friendship_repository_.friendshiprepository.md)