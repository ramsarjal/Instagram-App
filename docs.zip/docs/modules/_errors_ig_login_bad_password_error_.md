> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["errors/ig-login-bad-password.error"](_errors_ig_login_bad_password_error_.md) /

# External module: "errors/ig-login-bad-password.error"

## Index

### Classes

* [IgLoginBadPasswordError](../classes/_errors_ig_login_bad_password_error_.igloginbadpassworderror.md)