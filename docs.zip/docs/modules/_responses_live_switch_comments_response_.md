> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["responses/live.switch-comments.response"](_responses_live_switch_comments_response_.md) /

# External module: "responses/live.switch-comments.response"

## Index

### Interfaces

* [LiveSwitchCommentsResponseRootObject](../interfaces/_responses_live_switch_comments_response_.liveswitchcommentsresponserootobject.md)