> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["errors/ig-parse.error"](_errors_ig_parse_error_.md) /

# External module: "errors/ig-parse.error"

## Index

### Classes

* [IgParseError](../classes/_errors_ig_parse_error_.igparseerror.md)