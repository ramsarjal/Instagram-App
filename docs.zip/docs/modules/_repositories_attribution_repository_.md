> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["repositories/attribution.repository"](_repositories_attribution_repository_.md) /

# External module: "repositories/attribution.repository"

## Index

### Classes

* [AttributionRepository](../classes/_repositories_attribution_repository_.attributionrepository.md)