> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["repositories/direct.repository"](_repositories_direct_repository_.md) /

# External module: "repositories/direct.repository"

## Index

### Classes

* [DirectRepository](../classes/_repositories_direct_repository_.directrepository.md)