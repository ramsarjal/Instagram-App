> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["responses/media.repository.comment.response"](_responses_media_repository_comment_response_.md) /

# External module: "responses/media.repository.comment.response"

## Index

### Interfaces

* [MediaRepositoryCommentResponse](../interfaces/_responses_media_repository_comment_response_.mediarepositorycommentresponse.md)
* [MediaRepositoryCommentResponseComment](../interfaces/_responses_media_repository_comment_response_.mediarepositorycommentresponsecomment.md)
* [MediaRepositoryCommentResponseUser](../interfaces/_responses_media_repository_comment_response_.mediarepositorycommentresponseuser.md)