> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["responses/live.create-broadcast.response"](_responses_live_create_broadcast_response_.md) /

# External module: "responses/live.create-broadcast.response"

## Index

### Interfaces

* [LiveCreateBroadcastResponseRootObject](../interfaces/_responses_live_create_broadcast_response_.livecreatebroadcastresponserootobject.md)