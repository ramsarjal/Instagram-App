> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["responses/media.entity.oembed.response"](_responses_media_entity_oembed_response_.md) /

# External module: "responses/media.entity.oembed.response"

## Index

### Interfaces

* [MediaEntityOembedResponse](../interfaces/_responses_media_entity_oembed_response_.mediaentityoembedresponse.md)