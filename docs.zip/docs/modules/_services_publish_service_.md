> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["services/publish.service"](_services_publish_service_.md) /

# External module: "services/publish.service"

## Index

### Classes

* [PublishService](../classes/_services_publish_service_.publishservice.md)