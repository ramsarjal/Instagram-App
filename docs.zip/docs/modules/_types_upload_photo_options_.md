> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["types/upload.photo.options"](_types_upload_photo_options_.md) /

# External module: "types/upload.photo.options"

## Index

### Interfaces

* [UploadPhotoOptions](../interfaces/_types_upload_photo_options_.uploadphotooptions.md)