> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["responses/live.get-questions.response"](_responses_live_get_questions_response_.md) /

# External module: "responses/live.get-questions.response"

## Index

### Interfaces

* [LiveGetQuestionsResponseQuestionsItem](../interfaces/_responses_live_get_questions_response_.livegetquestionsresponsequestionsitem.md)
* [LiveGetQuestionsResponseRootObject](../interfaces/_responses_live_get_questions_response_.livegetquestionsresponserootobject.md)
* [LiveGetQuestionsResponseUser](../interfaces/_responses_live_get_questions_response_.livegetquestionsresponseuser.md)