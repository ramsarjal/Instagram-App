> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["errors/ig-network.error"](_errors_ig_network_error_.md) /

# External module: "errors/ig-network.error"

## Index

### Classes

* [IgNetworkError](../classes/_errors_ig_network_error_.ignetworkerror.md)