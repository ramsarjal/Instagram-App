> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["responses/upload.repository.photo.response"](_responses_upload_repository_photo_response_.md) /

# External module: "responses/upload.repository.photo.response"

## Index

### Interfaces

* [UploadRepositoryPhotoResponseRootObject](../interfaces/_responses_upload_repository_photo_response_.uploadrepositoryphotoresponserootobject.md)
* [UploadRepositoryPhotoResponseXsharing_nonces](../interfaces/_responses_upload_repository_photo_response_.uploadrepositoryphotoresponsexsharing_nonces.md)