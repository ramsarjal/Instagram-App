> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["feeds/tags.feed"](_feeds_tags_feed_.md) /

# External module: "feeds/tags.feed"

## Index

### Classes

* [TagsFeed](../classes/_feeds_tags_feed_.tagsfeed.md)