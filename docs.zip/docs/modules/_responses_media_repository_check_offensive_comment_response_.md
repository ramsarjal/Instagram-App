> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["responses/media.repository.check-offensive-comment.response"](_responses_media_repository_check_offensive_comment_response_.md) /

# External module: "responses/media.repository.check-offensive-comment.response"

## Index

### Interfaces

* [MediaRepositoryCheckOffensiveCommentResponseRootObject](../interfaces/_responses_media_repository_check_offensive_comment_response_.mediarepositorycheckoffensivecommentresponserootobject.md)