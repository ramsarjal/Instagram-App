> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["repositories/location.repository"](_repositories_location_repository_.md) /

# External module: "repositories/location.repository"

## Index

### Classes

* [LocationRepository](../classes/_repositories_location_repository_.locationrepository.md)