> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["types/account.two-factor-login.options"](_types_account_two_factor_login_options_.md) /

# External module: "types/account.two-factor-login.options"

## Index

### Interfaces

* [AccountTwoFactorLoginOptions](../interfaces/_types_account_two_factor_login_options_.accounttwofactorloginoptions.md)