> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["responses/fbsearch.repository.places.response"](_responses_fbsearch_repository_places_response_.md) /

# External module: "responses/fbsearch.repository.places.response"

## Index

### Interfaces

* [FbsearchRepositoryPlacesResponseHeader_media](../interfaces/_responses_fbsearch_repository_places_response_.fbsearchrepositoryplacesresponseheader_media.md)
* [FbsearchRepositoryPlacesResponseItemsItem](../interfaces/_responses_fbsearch_repository_places_response_.fbsearchrepositoryplacesresponseitemsitem.md)
* [FbsearchRepositoryPlacesResponseLocation](../interfaces/_responses_fbsearch_repository_places_response_.fbsearchrepositoryplacesresponselocation.md)
* [FbsearchRepositoryPlacesResponseRootObject](../interfaces/_responses_fbsearch_repository_places_response_.fbsearchrepositoryplacesresponserootobject.md)