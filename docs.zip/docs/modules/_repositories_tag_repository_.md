> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["repositories/tag.repository"](_repositories_tag_repository_.md) /

# External module: "repositories/tag.repository"

## Index

### Classes

* [TagRepository](../classes/_repositories_tag_repository_.tagrepository.md)