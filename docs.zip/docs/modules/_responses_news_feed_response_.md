> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["responses/news.feed.response"](_responses_news_feed_response_.md) /

# External module: "responses/news.feed.response"

## Index

### Classes

* [NewsFeedResponseStoriesItem](../classes/_responses_news_feed_response_.newsfeedresponsestoriesitem.md)

### Interfaces

* [NewsFeedResponseArgs](../interfaces/_responses_news_feed_response_.newsfeedresponseargs.md)
* [NewsFeedResponseCounts](../interfaces/_responses_news_feed_response_.newsfeedresponsecounts.md)
* [NewsFeedResponseLinksItem](../interfaces/_responses_news_feed_response_.newsfeedresponselinksitem.md)
* [NewsFeedResponseMediaItem](../interfaces/_responses_news_feed_response_.newsfeedresponsemediaitem.md)
* [NewsFeedResponseRootObject](../interfaces/_responses_news_feed_response_.newsfeedresponserootobject.md)