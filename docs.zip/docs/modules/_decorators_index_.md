> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["decorators/index"](_decorators_index_.md) /

# External module: "decorators/index"