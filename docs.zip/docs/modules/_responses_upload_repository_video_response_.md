> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["responses/upload.repository.video.response"](_responses_upload_repository_video_response_.md) /

# External module: "responses/upload.repository.video.response"

## Index

### Interfaces

* [UploadRepositoryVideoResponseRootObject](../interfaces/_responses_upload_repository_video_response_.uploadrepositoryvideoresponserootobject.md)
* [UploadRepositoryVideoResponseXsharing_nonces](../interfaces/_responses_upload_repository_video_response_.uploadrepositoryvideoresponsexsharing_nonces.md)