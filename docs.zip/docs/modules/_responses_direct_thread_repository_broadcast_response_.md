> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["responses/direct-thread.repository.broadcast.response"](_responses_direct_thread_repository_broadcast_response_.md) /

# External module: "responses/direct-thread.repository.broadcast.response"

## Index

### Interfaces

* [DirectThreadRepositoryBroadcastResponsePayload](../interfaces/_responses_direct_thread_repository_broadcast_response_.directthreadrepositorybroadcastresponsepayload.md)
* [DirectThreadRepositoryBroadcastResponseRootObject](../interfaces/_responses_direct_thread_repository_broadcast_response_.directthreadrepositorybroadcastresponserootobject.md)