> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["feeds/direct-pending.feed"](_feeds_direct_pending_feed_.md) /

# External module: "feeds/direct-pending.feed"

## Index

### Classes

* [DirectPendingInboxFeed](../classes/_feeds_direct_pending_feed_.directpendinginboxfeed.md)