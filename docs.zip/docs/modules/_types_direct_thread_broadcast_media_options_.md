> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["types/direct-thread.broadcast-media.options"](_types_direct_thread_broadcast_media_options_.md) /

# External module: "types/direct-thread.broadcast-media.options"

## Index

### Interfaces

* [DirectThreadBroadcastPhotoOptions](../interfaces/_types_direct_thread_broadcast_media_options_.directthreadbroadcastphotooptions.md)
* [DirectThreadBroadcastStoryOptions](../interfaces/_types_direct_thread_broadcast_media_options_.directthreadbroadcaststoryoptions.md)
* [DirectThreadBroadcastVideoOptions](../interfaces/_types_direct_thread_broadcast_media_options_.directthreadbroadcastvideooptions.md)