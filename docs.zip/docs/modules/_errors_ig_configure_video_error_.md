> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["errors/ig-configure-video-error"](_errors_ig_configure_video_error_.md) /

# External module: "errors/ig-configure-video-error"

## Index

### Classes

* [IgConfigureVideoError](../classes/_errors_ig_configure_video_error_.igconfigurevideoerror.md)