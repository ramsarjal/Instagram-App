> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["responses/media.repository.info.response"](_responses_media_repository_info_response_.md) /

# External module: "responses/media.repository.info.response"

## Index

### Interfaces

* [MediaEditResponseRootObject](../interfaces/_responses_media_repository_info_response_.mediaeditresponserootobject.md)
* [MediaInfoResponseCandidatesItem](../interfaces/_responses_media_repository_info_response_.mediainforesponsecandidatesitem.md)
* [MediaInfoResponseCaption](../interfaces/_responses_media_repository_info_response_.mediainforesponsecaption.md)
* [MediaInfoResponseFriendship_status](../interfaces/_responses_media_repository_info_response_.mediainforesponsefriendship_status.md)
* [MediaInfoResponseImage_versions2](../interfaces/_responses_media_repository_info_response_.mediainforesponseimage_versions2.md)
* [MediaInfoResponseItemsItem](../interfaces/_responses_media_repository_info_response_.mediainforesponseitemsitem.md)
* [MediaInfoResponseRootObject](../interfaces/_responses_media_repository_info_response_.mediainforesponserootobject.md)
* [MediaInfoResponseUser](../interfaces/_responses_media_repository_info_response_.mediainforesponseuser.md)