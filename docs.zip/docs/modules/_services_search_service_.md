> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["services/search.service"](_services_search_service_.md) /

# External module: "services/search.service"

## Index

### Classes

* [SearchService](../classes/_services_search_service_.searchservice.md)