> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["repositories/direct-thread.repository"](_repositories_direct_thread_repository_.md) /

# External module: "repositories/direct-thread.repository"

## Index

### Classes

* [DirectThreadRepository](../classes/_repositories_direct_thread_repository_.directthreadrepository.md)