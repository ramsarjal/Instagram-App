> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["responses/media.repository.blocked.response"](_responses_media_repository_blocked_response_.md) /

# External module: "responses/media.repository.blocked.response"

## Index

### Interfaces

* [MediaRepositoryBlockedResponse](../interfaces/_responses_media_repository_blocked_response_.mediarepositoryblockedresponse.md)