> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["responses/live.like-count.response"](_responses_live_like_count_response_.md) /

# External module: "responses/live.like-count.response"

## Index

### Interfaces

* [LiveLikeCountResponseRootObject](../interfaces/_responses_live_like_count_response_.livelikecountresponserootobject.md)