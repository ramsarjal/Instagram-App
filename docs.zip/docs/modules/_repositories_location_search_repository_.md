> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["repositories/location-search.repository"](_repositories_location_search_repository_.md) /

# External module: "repositories/location-search.repository"

## Index

### Classes

* [LocationSearch](../classes/_repositories_location_search_repository_.locationsearch.md)