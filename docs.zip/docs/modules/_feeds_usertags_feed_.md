> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["feeds/usertags.feed"](_feeds_usertags_feed_.md) /

# External module: "feeds/usertags.feed"

## Index

### Classes

* [UsertagsFeed](../classes/_feeds_usertags_feed_.usertagsfeed.md)