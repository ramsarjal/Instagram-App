> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["responses/usertags.feed.response"](_responses_usertags_feed_response_.md) /

# External module: "responses/usertags.feed.response"

## Index

### Interfaces

* [UsertagsFeedResponseCandidatesItem](../interfaces/_responses_usertags_feed_response_.usertagsfeedresponsecandidatesitem.md)
* [UsertagsFeedResponseCaption](../interfaces/_responses_usertags_feed_response_.usertagsfeedresponsecaption.md)
* [UsertagsFeedResponseFriendship_status](../interfaces/_responses_usertags_feed_response_.usertagsfeedresponsefriendship_status.md)
* [UsertagsFeedResponseImage_versions2](../interfaces/_responses_usertags_feed_response_.usertagsfeedresponseimage_versions2.md)
* [UsertagsFeedResponseInItem](../interfaces/_responses_usertags_feed_response_.usertagsfeedresponseinitem.md)
* [UsertagsFeedResponseItemsItem](../interfaces/_responses_usertags_feed_response_.usertagsfeedresponseitemsitem.md)
* [UsertagsFeedResponseLocation](../interfaces/_responses_usertags_feed_response_.usertagsfeedresponselocation.md)
* [UsertagsFeedResponsePreviewCommentsItem](../interfaces/_responses_usertags_feed_response_.usertagsfeedresponsepreviewcommentsitem.md)
* [UsertagsFeedResponseRootObject](../interfaces/_responses_usertags_feed_response_.usertagsfeedresponserootobject.md)
* [UsertagsFeedResponseUser](../interfaces/_responses_usertags_feed_response_.usertagsfeedresponseuser.md)
* [UsertagsFeedResponseUsertags](../interfaces/_responses_usertags_feed_response_.usertagsfeedresponseusertags.md)