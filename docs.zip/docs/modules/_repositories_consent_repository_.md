> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["repositories/consent.repository"](_repositories_consent_repository_.md) /

# External module: "repositories/consent.repository"

## Index

### Classes

* [ConsentRepository](../classes/_repositories_consent_repository_.consentrepository.md)