> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["feeds/index"](_feeds_index_.md) /

# External module: "feeds/index"