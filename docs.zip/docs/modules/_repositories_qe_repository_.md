> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["repositories/qe.repository"](_repositories_qe_repository_.md) /

# External module: "repositories/qe.repository"

## Index

### Classes

* [QeRepository](../classes/_repositories_qe_repository_.qerepository.md)