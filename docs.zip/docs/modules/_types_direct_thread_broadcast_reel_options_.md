> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["types/direct-thread.broadcast-reel.options"](_types_direct_thread_broadcast_reel_options_.md) /

# External module: "types/direct-thread.broadcast-reel.options"

## Index

### Interfaces

* [DirectThreadBroadcastReelOptions](../interfaces/_types_direct_thread_broadcast_reel_options_.directthreadbroadcastreeloptions.md)