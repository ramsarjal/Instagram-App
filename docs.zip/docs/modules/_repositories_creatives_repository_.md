> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["repositories/creatives.repository"](_repositories_creatives_repository_.md) /

# External module: "repositories/creatives.repository"

## Index

### Classes

* [CreativesRepository](../classes/_repositories_creatives_repository_.creativesrepository.md)