> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["errors/index"](_errors_index_.md) /

# External module: "errors/index"