> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["errors/ig-sentry-block.error"](_errors_ig_sentry_block_error_.md) /

# External module: "errors/ig-sentry-block.error"

## Index

### Classes

* [IgSentryBlockError](../classes/_errors_ig_sentry_block_error_.igsentryblockerror.md)