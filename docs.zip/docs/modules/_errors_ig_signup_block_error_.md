> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["errors/ig-signup-block.error"](_errors_ig_signup_block_error_.md) /

# External module: "errors/ig-signup-block.error"

## Index

### Classes

* [IgSignupBlockError](../classes/_errors_ig_signup_block_error_.igsignupblockerror.md)