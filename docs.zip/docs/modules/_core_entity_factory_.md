> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["core/entity.factory"](_core_entity_factory_.md) /

# External module: "core/entity.factory"

## Index

### Classes

* [EntityFactory](../classes/_core_entity_factory_.entityfactory.md)