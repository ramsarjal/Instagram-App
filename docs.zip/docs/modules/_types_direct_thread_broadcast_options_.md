> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["types/direct-thread.broadcast.options"](_types_direct_thread_broadcast_options_.md) /

# External module: "types/direct-thread.broadcast.options"

## Index

### Type aliases

* [DirectThreadBroadcastOptions](_types_direct_thread_broadcast_options_.md#directthreadbroadcastoptions)

## Type aliases

###  DirectThreadBroadcastOptions

Ƭ **DirectThreadBroadcastOptions**: *`DirectTreadBroadcastBaseOptions` & `XOR<ExistingThreadOptions, CreateThreadOptions>`*

*Defined in [types/direct-thread.broadcast.options.ts:18](https://github.com/dilame/instagram-private-api/blob/3e16058/src/types/direct-thread.broadcast.options.ts#L18)*