> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["feeds/user-story.feed"](_feeds_user_story_feed_.md) /

# External module: "feeds/user-story.feed"

## Index

### Classes

* [UserStoryFeed](../classes/_feeds_user_story_feed_.userstoryfeed.md)