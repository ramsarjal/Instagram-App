> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["types/posting.options"](_types_posting_options_.md) /

# External module: "types/posting.options"

## Index

### Interfaces

* [PostingLocation](../interfaces/_types_posting_options_.postinglocation.md)
* [PostingStoryLocationSticker](../interfaces/_types_posting_options_.postingstorylocationsticker.md)
* [PostingStoryOptions](../interfaces/_types_posting_options_.postingstoryoptions.md)
* [PostingUsertags](../interfaces/_types_posting_options_.postingusertags.md)