> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["responses/status.response"](_responses_status_response_.md) /

# External module: "responses/status.response"

## Index

### Interfaces

* [StatusResponse](../interfaces/_responses_status_response_.statusresponse.md)