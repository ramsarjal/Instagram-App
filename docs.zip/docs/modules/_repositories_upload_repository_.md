> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["repositories/upload.repository"](_repositories_upload_repository_.md) /

# External module: "repositories/upload.repository"

## Index

### Classes

* [UploadRepository](../classes/_repositories_upload_repository_.uploadrepository.md)