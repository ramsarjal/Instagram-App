> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["feeds/account-followers.feed"](_feeds_account_followers_feed_.md) /

# External module: "feeds/account-followers.feed"

## Index

### Classes

* [AccountFollowersFeed](../classes/_feeds_account_followers_feed_.accountfollowersfeed.md)