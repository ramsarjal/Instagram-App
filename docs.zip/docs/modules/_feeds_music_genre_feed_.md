> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["feeds/music-genre.feed"](_feeds_music_genre_feed_.md) /

# External module: "feeds/music-genre.feed"

## Index

### Classes

* [MusicGenreFeed](../classes/_feeds_music_genre_feed_.musicgenrefeed.md)