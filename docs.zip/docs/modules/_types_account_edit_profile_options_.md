> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["types/account.edit-profile.options"](_types_account_edit_profile_options_.md) /

# External module: "types/account.edit-profile.options"

## Index

### Interfaces

* [AccountEditProfileOptions](../interfaces/_types_account_edit_profile_options_.accounteditprofileoptions.md)