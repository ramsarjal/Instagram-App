> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["errors/ig-requests-limit.error"](_errors_ig_requests_limit_error_.md) /

# External module: "errors/ig-requests-limit.error"

## Index

### Classes

* [IgRequestsLimitError](../classes/_errors_ig_requests_limit_error_.igrequestslimiterror.md)