> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["types/media.configure-video.options"](_types_media_configure_video_options_.md) /

# External module: "types/media.configure-video.options"

## Index

### Interfaces

* [MediaConfigureTimelineVideoOptions](../interfaces/_types_media_configure_video_options_.mediaconfiguretimelinevideooptions.md)
* [MediaConfigureVideoOptions](../interfaces/_types_media_configure_video_options_.mediaconfigurevideooptions.md)