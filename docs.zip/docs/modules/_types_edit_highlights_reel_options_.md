> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["types/edit-highlights-reel.options"](_types_edit_highlights_reel_options_.md) /

# External module: "types/edit-highlights-reel.options"

## Index

### Interfaces

* [EditHighlightsReelOptions](../interfaces/_types_edit_highlights_reel_options_.edithighlightsreeloptions.md)