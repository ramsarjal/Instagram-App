> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["responses/music-mood.feed.response"](_responses_music_mood_feed_response_.md) /

# External module: "responses/music-mood.feed.response"

## Index

### Interfaces

* [MusicMoodFeedResponseItemsItem](../interfaces/_responses_music_mood_feed_response_.musicmoodfeedresponseitemsitem.md)
* [MusicMoodFeedResponsePage_info](../interfaces/_responses_music_mood_feed_response_.musicmoodfeedresponsepage_info.md)
* [MusicMoodFeedResponseRootObject](../interfaces/_responses_music_mood_feed_response_.musicmoodfeedresponserootobject.md)
* [MusicMoodFeedResponseTrack](../interfaces/_responses_music_mood_feed_response_.musicmoodfeedresponsetrack.md)