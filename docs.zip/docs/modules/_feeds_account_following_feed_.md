> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["feeds/account-following.feed"](_feeds_account_following_feed_.md) /

# External module: "feeds/account-following.feed"

## Index

### Classes

* [AccountFollowingFeed](../classes/_feeds_account_following_feed_.accountfollowingfeed.md)