> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["responses/account-friendships.feed.response"](_responses_account_friendships_feed_response_.md) /

# External module: "responses/account-friendships.feed.response"

## Index

### Classes

* [PendingFriendshipsFeedResponseUsersItem](../classes/_responses_account_friendships_feed_response_.pendingfriendshipsfeedresponseusersitem.md)

### Interfaces

* [PendingFriendshipsFeedResponse](../interfaces/_responses_account_friendships_feed_response_.pendingfriendshipsfeedresponse.md)