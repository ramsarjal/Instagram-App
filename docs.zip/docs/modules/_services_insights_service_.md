> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["services/insights.service"](_services_insights_service_.md) /

# External module: "services/insights.service"

## Index

### Classes

* [InsightsService](../classes/_services_insights_service_.insightsservice.md)