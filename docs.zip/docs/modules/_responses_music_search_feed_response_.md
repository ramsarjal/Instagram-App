> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["responses/music-search.feed.response"](_responses_music_search_feed_response_.md) /

# External module: "responses/music-search.feed.response"

## Index

### Interfaces

* [MusicSearchFeedResponseItemsItem](../interfaces/_responses_music_search_feed_response_.musicsearchfeedresponseitemsitem.md)
* [MusicSearchFeedResponsePage_info](../interfaces/_responses_music_search_feed_response_.musicsearchfeedresponsepage_info.md)
* [MusicSearchFeedResponseRootObject](../interfaces/_responses_music_search_feed_response_.musicsearchfeedresponserootobject.md)
* [MusicSearchFeedResponseTrack](../interfaces/_responses_music_search_feed_response_.musicsearchfeedresponsetrack.md)