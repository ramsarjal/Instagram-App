> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["feeds/posts-insights.feed"](_feeds_posts_insights_feed_.md) /

# External module: "feeds/posts-insights.feed"

## Index

### Classes

* [PostsInsightsFeed](../classes/_feeds_posts_insights_feed_.postsinsightsfeed.md)