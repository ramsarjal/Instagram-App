> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["feeds/account-friendships.feed"](_feeds_account_friendships_feed_.md) /

# External module: "feeds/account-friendships.feed"

## Index

### Classes

* [PendingFriendshipsFeed](../classes/_feeds_account_friendships_feed_.pendingfriendshipsfeed.md)