> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["services/simulate.service"](_services_simulate_service_.md) /

# External module: "services/simulate.service"

## Index

### Classes

* [SimulateService](../classes/_services_simulate_service_.simulateservice.md)