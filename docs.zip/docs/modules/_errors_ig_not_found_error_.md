> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["errors/ig-not-found.error"](_errors_ig_not_found_error_.md) /

# External module: "errors/ig-not-found.error"

## Index

### Classes

* [IgNotFoundError](../classes/_errors_ig_not_found_error_.ignotfounderror.md)