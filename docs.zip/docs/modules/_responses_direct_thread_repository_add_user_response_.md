> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["responses/direct-thread.repository.add-user.response"](_responses_direct_thread_repository_add_user_response_.md) /

# External module: "responses/direct-thread.repository.add-user.response"

## Index

### Interfaces

* [DirectThreadRepositoryAddUserResponseActionLog](../interfaces/_responses_direct_thread_repository_add_user_response_.directthreadrepositoryadduserresponseactionlog.md)
* [DirectThreadRepositoryAddUserResponseBoldItem](../interfaces/_responses_direct_thread_repository_add_user_response_.directthreadrepositoryadduserresponsebolditem.md)
* [DirectThreadRepositoryAddUserResponseFriendshipStatus](../interfaces/_responses_direct_thread_repository_add_user_response_.directthreadrepositoryadduserresponsefriendshipstatus.md)
* [DirectThreadRepositoryAddUserResponseInviter](../interfaces/_responses_direct_thread_repository_add_user_response_.directthreadrepositoryadduserresponseinviter.md)
* [DirectThreadRepositoryAddUserResponseLastPermanentItem](../interfaces/_responses_direct_thread_repository_add_user_response_.directthreadrepositoryadduserresponselastpermanentitem.md)
* [DirectThreadRepositoryAddUserResponseRootObject](../interfaces/_responses_direct_thread_repository_add_user_response_.directthreadrepositoryadduserresponserootobject.md)
* [DirectThreadRepositoryAddUserResponseTextAttributesItem](../interfaces/_responses_direct_thread_repository_add_user_response_.directthreadrepositoryadduserresponsetextattributesitem.md)
* [DirectThreadRepositoryAddUserResponseThread](../interfaces/_responses_direct_thread_repository_add_user_response_.directthreadrepositoryadduserresponsethread.md)
* [DirectThreadRepositoryAddUserResponseUsersItem](../interfaces/_responses_direct_thread_repository_add_user_response_.directthreadrepositoryadduserresponseusersitem.md)