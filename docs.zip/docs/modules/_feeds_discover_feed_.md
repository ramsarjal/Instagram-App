> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["feeds/discover.feed"](_feeds_discover_feed_.md) /

# External module: "feeds/discover.feed"

## Index

### Classes

* [DiscoverFeed](../classes/_feeds_discover_feed_.discoverfeed.md)