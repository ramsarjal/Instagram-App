> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["responses/posts-insights.feed.response"](_responses_posts_insights_feed_response_.md) /

# External module: "responses/posts-insights.feed.response"

## Index

### Interfaces

* [PostsInsightsFeedResponseActions](../interfaces/_responses_posts_insights_feed_response_.postsinsightsfeedresponseactions.md)
* [PostsInsightsFeedResponseBusiness_manager](../interfaces/_responses_posts_insights_feed_response_.postsinsightsfeedresponsebusiness_manager.md)
* [PostsInsightsFeedResponseData](../interfaces/_responses_posts_insights_feed_response_.postsinsightsfeedresponsedata.md)
* [PostsInsightsFeedResponseEdgesItem](../interfaces/_responses_posts_insights_feed_response_.postsinsightsfeedresponseedgesitem.md)
* [PostsInsightsFeedResponseImage](../interfaces/_responses_posts_insights_feed_response_.postsinsightsfeedresponseimage.md)
* [PostsInsightsFeedResponseInline_insights_node](../interfaces/_responses_posts_insights_feed_response_.postsinsightsfeedresponseinline_insights_node.md)
* [PostsInsightsFeedResponseMetrics](../interfaces/_responses_posts_insights_feed_response_.postsinsightsfeedresponsemetrics.md)
* [PostsInsightsFeedResponseNode](../interfaces/_responses_posts_insights_feed_response_.postsinsightsfeedresponsenode.md)
* [PostsInsightsFeedResponsePage_info](../interfaces/_responses_posts_insights_feed_response_.postsinsightsfeedresponsepage_info.md)
* [PostsInsightsFeedResponseProfile_actions](../interfaces/_responses_posts_insights_feed_response_.postsinsightsfeedresponseprofile_actions.md)
* [PostsInsightsFeedResponseRootObject](../interfaces/_responses_posts_insights_feed_response_.postsinsightsfeedresponserootobject.md)
* [PostsInsightsFeedResponseShare_count](../interfaces/_responses_posts_insights_feed_response_.postsinsightsfeedresponseshare_count.md)
* [PostsInsightsFeedResponseTop_posts](../interfaces/_responses_posts_insights_feed_response_.postsinsightsfeedresponsetop_posts.md)
* [PostsInsightsFeedResponseTop_posts_unit](../interfaces/_responses_posts_insights_feed_response_.postsinsightsfeedresponsetop_posts_unit.md)
* [PostsInsightsFeedResponseTray](../interfaces/_responses_posts_insights_feed_response_.postsinsightsfeedresponsetray.md)
* [PostsInsightsFeedResponseUser](../interfaces/_responses_posts_insights_feed_response_.postsinsightsfeedresponseuser.md)