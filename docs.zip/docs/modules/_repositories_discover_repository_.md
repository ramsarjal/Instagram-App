> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["repositories/discover.repository"](_repositories_discover_repository_.md) /

# External module: "repositories/discover.repository"

## Index

### Classes

* [DiscoverRepository](../classes/_repositories_discover_repository_.discoverrepository.md)