> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["responses/challenge.state.response"](_responses_challenge_state_response_.md) /

# External module: "responses/challenge.state.response"

## Index

### Interfaces

* [ChallengeRepositoryStateResponseStepData](../interfaces/_responses_challenge_state_response_.challengerepositorystateresponsestepdata.md)
* [ChallengeStateResponse](../interfaces/_responses_challenge_state_response_.challengestateresponse.md)