> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["errors/ig-login-two-factor-required.error"](_errors_ig_login_two_factor_required_error_.md) /

# External module: "errors/ig-login-two-factor-required.error"

## Index

### Classes

* [IgLoginTwoFactorRequiredError](../classes/_errors_ig_login_two_factor_required_error_.iglogintwofactorrequirederror.md)