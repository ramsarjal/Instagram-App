> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["errors/ig-user-id-not-found.error"](_errors_ig_user_id_not_found_error_.md) /

# External module: "errors/ig-user-id-not-found.error"

## Index

### Classes

* [IgUserIdNotFoundError](../classes/_errors_ig_user_id_not_found_error_.iguseridnotfounderror.md)