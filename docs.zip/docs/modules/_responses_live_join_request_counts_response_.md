> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["responses/live.join-request-counts.response"](_responses_live_join_request_counts_response_.md) /

# External module: "responses/live.join-request-counts.response"

## Index

### Interfaces

* [LiveJoinRequestCountsResponseRootObject](../interfaces/_responses_live_join_request_counts_response_.livejoinrequestcountsresponserootobject.md)
* [LiveJoinRequestCountsResponseUsersItem](../interfaces/_responses_live_join_request_counts_response_.livejoinrequestcountsresponseusersitem.md)