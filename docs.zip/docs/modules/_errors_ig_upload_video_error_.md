> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["errors/ig-upload-video-error"](_errors_ig_upload_video_error_.md) /

# External module: "errors/ig-upload-video-error"

## Index

### Classes

* [IgUploadVideoError](../classes/_errors_ig_upload_video_error_.iguploadvideoerror.md)