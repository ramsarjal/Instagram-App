> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["feeds/media-comments.feed"](_feeds_media_comments_feed_.md) /

# External module: "feeds/media-comments.feed"

## Index

### Classes

* [MediaCommentsFeed](../classes/_feeds_media_comments_feed_.mediacommentsfeed.md)