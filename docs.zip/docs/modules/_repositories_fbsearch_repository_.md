> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["repositories/fbsearch.repository"](_repositories_fbsearch_repository_.md) /

# External module: "repositories/fbsearch.repository"

## Index

### Classes

* [FbsearchRepository](../classes/_repositories_fbsearch_repository_.fbsearchrepository.md)