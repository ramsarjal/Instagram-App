> **[instagram-private-api](../README.md)**

[Globals](../README.md) / ["feeds/blocked-users.feed"](_feeds_blocked_users_feed_.md) /

# External module: "feeds/blocked-users.feed"

## Index

### Classes

* [BlockedUsersFeed](../classes/_feeds_blocked_users_feed_.blockedusersfeed.md)